﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1;
using MySql.Data.MySqlClient;
using System.Net;
using System.Net.Mail;
using System.Configuration;
using System.Drawing.Imaging;
using System.IO;

namespace WindowsFormsApp1
{
    public partial class frmAdmin : Form
    {
        clsConnection obj = new clsConnection();
        public frmAdmin()
        {
            InitializeComponent();
        }

        private void frmAdmin_Load(object sender, EventArgs e)
        {
            papulate_dropdown();
           
        }
        private void papulate_dropdown()
        {
            String sql = "select * from countries";
            obj.conn_open();
            MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
            MySqlDataReader dr;
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                cboCountry.AddItem(dr[0].ToString());
            }
            dr.Dispose();
            obj.conn_close();
        }
        private void label1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void bunifuDatepicker1_onValueChanged(object sender, EventArgs e)
        {
            txtdate.Text = datetimePicker.Value.ToString("yyyy-MM-dd");
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            clearobjects();
        }
        private void clearobjects()
        {
            txtId.Text = "";
            txtFName.Text = "";
            txtPhone.Text = "";
            txtAltPhone.Text = "";
            txtpob.Text = "";
            txtdate.Text = "";
            txtcity.Text = "";
            txtprovince.Text = "";
            txtemail.Text = "";
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtId.Text=="")
            {
                MessageBox.Show("Enter Identification");
                txtId.Focus();
                return;
            }
            if (txtFName.Text == "")
            {
                MessageBox.Show("Enter Full Name");
                txtFName.Focus();
                return;
            }
            if (txtPhone.Text == "")
            {
                MessageBox.Show("Enter Phone");
                txtPhone.Focus();
                return;
            }
            if (txtAltPhone.Text == "")
            {
                MessageBox.Show("Enter Alternate Phone");
                txtAltPhone.Focus();
                return;
            }
            if (txtpob.Text == "")
            {
                MessageBox.Show("Enter Place of Birth");
                txtpob.Focus();
                return;
            }
            if (txtdate.Text == "")
            {
                MessageBox.Show("Select Date");
                txtdate.Focus();
                return;
            }
            if (txtcity.Text == "")
            {
                MessageBox.Show("Enter City");
                txtcity.Focus();
                return;
            }
            if (txtprovince.Text == "")
            {
                MessageBox.Show("Enter Province");
                txtprovince.Focus();
                return;
            }
            if (cboCountry.selectedIndex == -1)
            {
                MessageBox.Show("Select Country");
                cboCountry.Focus();
                return;
            }
            if (txtemail.Text == "")
            {
                MessageBox.Show("Enter email");
                txtemail.Focus();
                return;
            }
           
            if (cboRole.selectedIndex == -1)
            {
                MessageBox.Show("Select User Role");
                cboRole.Focus();
                return;
            }
            System.Text.RegularExpressions.Regex rEMail = new System.Text.RegularExpressions.Regex(@"^[a-zA-Z][\w\.-]{2,28}[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$");
            if (txtemail.Text.Length > 0)
            {
                if (!rEMail.IsMatch(txtemail.Text))
                {
                    MessageBox.Show("E-Mail expected", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtemail.Text = "";
                    txtemail.Focus();
                    return;
                }
            }


            if (!is_record_exist(txtId.Text))
            {
                add_record();
                MessageBox.Show("Record Successfully Added!");
            }
            else
            {
                if (MessageBox.Show("Do you want to update?", "User Info", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                   
                    Update_record();
                    MessageBox.Show("Record Successfully Updated!");
                }
             
            }

            clearobjects();
           
            //send_mail(txtemail.Text);

            //this.Close();
           

        }

        private void send_mail(String txt)
        {
            try
            {
                MailMessage mail = new MailMessage();
                SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");

                mail.From = new MailAddress("wisemanderie@gmail.com","Jeeb System",Encoding.UTF8);
                mail.To.Add(txt);
                mail.Subject = "Welcome To jeeb System";
                mail.Body = "Your password is '123456'";

                SmtpServer.Port = 587;
                SmtpServer.Credentials = new System.Net.NetworkCredential("wisemanderie", "diiriyeaamino");
                SmtpServer.EnableSsl = true;

                SmtpServer.Send(mail);

               /* MailMessage mail = new MailMessage("wisemanderie@gmail.com", txt);
                SmtpClient client = new SmtpClient();
                client.Port = 587;
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.UseDefaultCredentials = false;
                client.Host = "smtp.gmail.com";
                mail.Subject = "this is a test email.";
                mail.Body = "this is my test email body";
                client.Send(mail);*/
                MessageBox.Show("mail Send");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
        private void add_record()
        {
            MemoryStream ms = new MemoryStream();
            pictureBox3.Image.Save(ms, ImageFormat.Jpeg);
            byte[] photo_aray = new byte[ms.Length];
            ms.Position = 0;
            ms.Read(photo_aray, 0, photo_aray.Length);


            MySqlCommand cmd = new MySqlCommand();
            MySqlParameter prm = new MySqlParameter();
            String sql = "Insert into admin_table (id,name,Email,Pass,phone,AltPhone,POB,DOB,City,Province,Country,Reg_Date,photo,Role,Hint,type )";
            sql += " values(@id,@name,@Email,@Pass,@phone,@AltPhone,@POB,@DOB,@City,@Province,@Country,@Reg_Date,@photo,@Role,@Hint,@type )";
            obj.conn_open();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = obj.cnn;
            cmd.CommandText = sql; 
            cmd.Parameters.AddWithValue("@id", txtId.Text);
            cmd.Parameters.AddWithValue("@name", txtFName.Text);
            cmd.Parameters.AddWithValue("@Email", txtemail.Text);
            cmd.Parameters.AddWithValue("@Pass", datetimePicker.Value.ToString("yyMMdd"));
            cmd.Parameters.AddWithValue("@phone", txtPhone.Text);
            cmd.Parameters.AddWithValue("@AltPhone", txtAltPhone.Text);
            cmd.Parameters.AddWithValue("@POB", txtpob.Text);
            cmd.Parameters.AddWithValue("@DOB", Convert.ToDateTime( txtdate.Text));// DateTime.Now;
            cmd.Parameters.AddWithValue("@City", txtcity.Text);
            cmd.Parameters.AddWithValue("@Province", txtprovince.Text);
            cmd.Parameters.AddWithValue("@Country", cboCountry.selectedValue);
            cmd.Parameters.AddWithValue("@Reg_Date", DateTime.Now);
            cmd.Parameters.AddWithValue("@photo", photo_aray);
            cmd.Parameters.AddWithValue("@Role", cboRole.selectedValue);
            cmd.Parameters.AddWithValue("@Hint", "your password is your birthday with a format of yymmdd");
            cmd.Parameters.AddWithValue("@type", cbotype.selectedValue);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            obj.conn_close();
        }
        private void Update_record()
        {
            MemoryStream ms = new MemoryStream();
            pictureBox3.Image.Save(ms, ImageFormat.Jpeg);
            byte[] photo_aray = new byte[ms.Length];
            ms.Position = 0;
            ms.Read(photo_aray, 0, photo_aray.Length);

            MySqlCommand cmd = new MySqlCommand();
            MySqlParameter prm = new MySqlParameter();
            String sql = "update admin_table set name=@name,Email=@Email,Pass=@Pass,phone=@phone,AltPhone=@AltPhone,POB=@POB," +
                "DOB=@DOB,City=@City,Province=@Province,Country=@Country,Reg_Date=@Reg_Date,photo=@photo,Role=@Role,Hint=@Hint,type=@type " +
                " where id=@id";
           
            obj.conn_open();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = obj.cnn;
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@id", txtId.Text);
            cmd.Parameters.AddWithValue("@name", txtFName.Text);
            cmd.Parameters.AddWithValue("@Email", txtemail.Text);
            cmd.Parameters.AddWithValue("@Pass", datetimePicker.Value.ToString("yyMMdd"));
            cmd.Parameters.AddWithValue("@phone", txtPhone.Text);
            cmd.Parameters.AddWithValue("@AltPhone", txtAltPhone.Text);
            cmd.Parameters.AddWithValue("@POB", txtpob.Text);
            cmd.Parameters.AddWithValue("@DOB", Convert.ToDateTime(txtdate.Text));// DateTime.Now;
            cmd.Parameters.AddWithValue("@City", txtcity.Text);
            cmd.Parameters.AddWithValue("@Province", txtprovince.Text);
            cmd.Parameters.AddWithValue("@Country", cboCountry.selectedValue);
            cmd.Parameters.AddWithValue("@Reg_Date", DateTime.Now);
            cmd.Parameters.AddWithValue("@photo", photo_aray);
            cmd.Parameters.AddWithValue("@Role", cboRole.selectedValue);
            cmd.Parameters.AddWithValue("@Hint", "your password is your birthday with a format of yymmdd");
            cmd.Parameters.AddWithValue("@type", cbotype.selectedValue);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            obj.conn_close();
        }
        private bool is_record_exist(String id)
        {
            obj.conn_open();
            String sql = "Select * from admin_table where id='" + id + "'";
            MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
            MySqlDataReader dr;
            dr = cmd.ExecuteReader();
            if (dr.Read())
                {
                dr.Dispose();
                obj.conn_close();
                return true;
                }
            else
                {
                dr.Dispose();
                obj.conn_close();
                return false;
                }
        }

        private void cboRole_onItemSelected(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            /* MailMessage mail = new MailMessage();
             SmtpClient SmtpServer = new SmtpClient("smtp.gmail.com");

             mail.From = new MailAddress("wisemanderie@gmail.com", "Jeeb System", Encoding.UTF8);
             mail.To.Add("abdulrazak.dirie@gmail.com");
             mail.Subject = "Welcome To jeeb System";
             mail.Body = "Your password is '123456'";

             SmtpServer.Port = 587;
             SmtpServer.Credentials = new System.Net.NetworkCredential("wisemanderie", "diiriyeaamino");
             SmtpServer.EnableSsl = true;

             SmtpServer.Send(mail);*/

            MailMessage mail = new MailMessage();
            mail.To.Add("wisemanderie@gmail.com");
            mail.From = new MailAddress("abdulrazak.dirie@gmail.com", "Jeeb System", Encoding.UTF8);
            mail.Subject = "Welcome To jeeb System";
            mail.Body = "Your password is '123456'";
            mail.IsBodyHtml = true;
            SmtpClient smtp = new SmtpClient("smtp.gmail.com", 465);
            smtp.EnableSsl = true;
            
            
            smtp.UseDefaultCredentials = false;
            smtp.Credentials = new System.Net.NetworkCredential("abdulrazak.dirie@gmail.com", "diiriye1992");
            smtp.Send(mail);

            MessageBox.Show("mail Send");
        }

        private void txtId_Leave(object sender, EventArgs e)
        {
            read_admin(txtId.Text);
        }
        private void read_admin(string id)
        {
            obj.conn_open();
            String sql = "Select * from admin_table where id='" + txtId.Text + "'";
            MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
            MySqlDataReader dr;
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                txtId.Text = dr[0].ToString();
                txtFName.Text = dr[1].ToString();
                txtPhone.Text = dr[4].ToString();
                txtAltPhone.Text = dr[5].ToString();
                txtpob.Text = dr[6].ToString();
                txtdate.Text = dr[7].ToString();
                txtcity.Text = dr[8].ToString();
                txtprovince.Text = dr[9].ToString();
                cboCountry.Text = dr[10].ToString();
                cboRole.Text = dr[12].ToString();
                txtemail.Text = dr[2].ToString();
            }
            dr.Dispose();
            obj.conn_close();
        }
   

        private void txtFName_Enter(object sender, EventArgs e)
        {
            if (txtId.Text != "")
            {
                read_admin(txtId.Text);
            }
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            if (txtFName.Text == "")
            {
                MessageBox.Show("Enter Full Name");
                txtFName.Focus();
                return;
            }
            if (txtPhone.Text == "")
            {
                MessageBox.Show("Enter Phone");
                txtPhone.Focus();
                return;
            }
            if (txtAltPhone.Text == "")
            {
                MessageBox.Show("Enter Alternate Phone");
                txtAltPhone.Focus();
                return;
            }
            if (txtpob.Text == "")
            {
                MessageBox.Show("Enter Place of Birth");
                txtpob.Focus();
                return;
            }
            if (txtdate.Text == "")
            {
                MessageBox.Show("Select Date");
                txtdate.Focus();
                return;
            }
            if (txtcity.Text == "")
            {
                MessageBox.Show("Enter City");
                txtcity.Focus();
                return;
            }
            if (txtprovince.Text == "")
            {
                MessageBox.Show("Enter Province");
                txtprovince.Focus();
                return;
            }
            if (cboCountry.selectedIndex == -1)
            {
                MessageBox.Show("Select Country");
                cboCountry.Focus();
                return;
            }

            if (MessageBox.Show("Do you want to update?", "User Info", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {

                Update_record2();
                MessageBox.Show("Record Successfully Updated!");
                clearobjects();
            }

        }

        private void Update_record2()
        {
            MySqlCommand cmd = new MySqlCommand();
            MySqlParameter prm = new MySqlParameter();
            String sql = "update admin_table set name=@name,phone=@phone,AltPhone=@AltPhone,POB=@POB," +
                "DOB=@DOB,City=@City,Province=@Province,Country=@Country where id=@id";

            obj.conn_open();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = obj.cnn;
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@id", txtId.Text);
            cmd.Parameters.AddWithValue("@name", txtFName.Text);
            cmd.Parameters.AddWithValue("@phone", txtPhone.Text);
            cmd.Parameters.AddWithValue("@AltPhone", txtAltPhone.Text);
            cmd.Parameters.AddWithValue("@POB", txtpob.Text);
            cmd.Parameters.AddWithValue("@DOB", Convert.ToDateTime(txtdate.Text));// DateTime.Now;
            cmd.Parameters.AddWithValue("@City", txtcity.Text);
            cmd.Parameters.AddWithValue("@Province", txtprovince.Text);
            cmd.Parameters.AddWithValue("@Country", cboCountry.selectedValue);

            cmd.ExecuteNonQuery();
            cmd.Dispose();
            obj.conn_close();
        }
    }
}
