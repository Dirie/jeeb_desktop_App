﻿namespace WindowsFormsApp1
{
    partial class frmlogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmlogin));
            this.panel1 = new System.Windows.Forms.Panel();
            this.cbotype = new Bunifu.Framework.UI.BunifuDropdown();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.txtemail = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panellogin = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtpass = new System.Windows.Forms.TextBox();
            this.bunifuFlatButton1 = new Bunifu.Framework.UI.BunifuFlatButton();
            this.lblRegister = new System.Windows.Forms.Label();
            this.panel_register = new System.Windows.Forms.Panel();
            this.txtcomCpass = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.txtcomPass = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.txtcomEmail = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.txtcountry = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.txtprovince = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.txtcity = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.txtaltPhone = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.txtphone = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtLastName = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.txtfname = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.txtcompanyName = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.btnSignup = new Bunifu.Framework.UI.BunifuFlatButton();
            this.lblLogIn = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panellogin.SuspendLayout();
            this.panel_register.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.cbotype);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(329, 33);
            this.panel1.TabIndex = 0;
            // 
            // cbotype
            // 
            this.cbotype.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(39)))), ((int)(((byte)(59)))));
            this.cbotype.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.cbotype.BorderRadius = 5;
            this.cbotype.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cbotype.DisabledColor = System.Drawing.Color.Gray;
            this.cbotype.ForeColor = System.Drawing.Color.White;
            this.cbotype.Items = new string[] {
        "Company",
        "Admin"};
            this.cbotype.Location = new System.Drawing.Point(113, 5);
            this.cbotype.Name = "cbotype";
            this.cbotype.NomalColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(39)))), ((int)(((byte)(59)))));
            this.cbotype.onHoverColor = System.Drawing.Color.FromArgb(((int)(((byte)(43)))), ((int)(((byte)(39)))), ((int)(((byte)(59)))));
            this.cbotype.selectedIndex = -1;
            this.cbotype.Size = new System.Drawing.Size(109, 24);
            this.cbotype.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Corbel", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(278, 1);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(22, 26);
            this.label3.TabIndex = 5;
            this.label3.Text = "_";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Corbel", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(302, 2);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(25, 26);
            this.label2.TabIndex = 5;
            this.label2.Text = "X";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.LinkColor = System.Drawing.Color.White;
            this.linkLabel1.Location = new System.Drawing.Point(144, 322);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(123, 19);
            this.linkLabel1.TabIndex = 4;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Forget Password?";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 15;
            this.bunifuElipse1.TargetControl = this;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(82, 28);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(140, 141);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.panel1;
            this.bunifuDragControl1.Vertical = true;
            // 
            // txtemail
            // 
            this.txtemail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtemail.ForeColor = System.Drawing.Color.White;
            this.txtemail.HintForeColor = System.Drawing.Color.White;
            this.txtemail.HintText = "Email";
            this.txtemail.isPassword = false;
            this.txtemail.LineFocusedColor = System.Drawing.Color.LightSkyBlue;
            this.txtemail.LineIdleColor = System.Drawing.Color.LightSkyBlue;
            this.txtemail.LineMouseHoverColor = System.Drawing.Color.LightSkyBlue;
            this.txtemail.LineThickness = 3;
            this.txtemail.Location = new System.Drawing.Point(66, 238);
            this.txtemail.Margin = new System.Windows.Forms.Padding(4);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(203, 30);
            this.txtemail.TabIndex = 7;
            this.txtemail.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtemail.OnValueChanged += new System.EventHandler(this.txtemail_OnValueChanged);
            this.txtemail.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtemail_KeyPress);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(38, 242);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(28, 29);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(37, 280);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(28, 29);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 6;
            this.pictureBox3.TabStop = false;
            // 
            // panellogin
            // 
            this.panellogin.Controls.Add(this.panel2);
            this.panellogin.Controls.Add(this.txtpass);
            this.panellogin.Controls.Add(this.bunifuFlatButton1);
            this.panellogin.Controls.Add(this.pictureBox1);
            this.panellogin.Controls.Add(this.pictureBox3);
            this.panellogin.Controls.Add(this.linkLabel1);
            this.panellogin.Controls.Add(this.lblRegister);
            this.panellogin.Controls.Add(this.txtemail);
            this.panellogin.Controls.Add(this.pictureBox2);
            this.panellogin.Location = new System.Drawing.Point(9, 39);
            this.panellogin.Name = "panellogin";
            this.panellogin.Size = new System.Drawing.Size(314, 525);
            this.panellogin.TabIndex = 8;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightSkyBlue;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Location = new System.Drawing.Point(66, 306);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(203, 4);
            this.panel2.TabIndex = 10;
            // 
            // txtpass
            // 
            this.txtpass.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(28)))), ((int)(((byte)(38)))));
            this.txtpass.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpass.ForeColor = System.Drawing.Color.White;
            this.txtpass.Location = new System.Drawing.Point(70, 285);
            this.txtpass.Name = "txtpass";
            this.txtpass.Size = new System.Drawing.Size(199, 17);
            this.txtpass.TabIndex = 9;
            this.txtpass.Text = "Password";
            this.txtpass.UseSystemPasswordChar = true;
            this.txtpass.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtpass_KeyPress);
            // 
            // bunifuFlatButton1
            // 
            this.bunifuFlatButton1.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.bunifuFlatButton1.BackColor = System.Drawing.Color.DodgerBlue;
            this.bunifuFlatButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuFlatButton1.BorderRadius = 0;
            this.bunifuFlatButton1.ButtonText = "LogIn";
            this.bunifuFlatButton1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.bunifuFlatButton1.DisabledColor = System.Drawing.Color.Gray;
            this.bunifuFlatButton1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton1.Iconcolor = System.Drawing.Color.Transparent;
            this.bunifuFlatButton1.Iconimage = null;
            this.bunifuFlatButton1.Iconimage_right = null;
            this.bunifuFlatButton1.Iconimage_right_Selected = null;
            this.bunifuFlatButton1.Iconimage_Selected = null;
            this.bunifuFlatButton1.IconMarginLeft = 0;
            this.bunifuFlatButton1.IconMarginRight = 0;
            this.bunifuFlatButton1.IconRightVisible = true;
            this.bunifuFlatButton1.IconRightZoom = 0D;
            this.bunifuFlatButton1.IconVisible = true;
            this.bunifuFlatButton1.IconZoom = 90D;
            this.bunifuFlatButton1.IsTab = false;
            this.bunifuFlatButton1.Location = new System.Drawing.Point(37, 391);
            this.bunifuFlatButton1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.bunifuFlatButton1.Name = "bunifuFlatButton1";
            this.bunifuFlatButton1.Normalcolor = System.Drawing.Color.DodgerBlue;
            this.bunifuFlatButton1.OnHovercolor = System.Drawing.Color.LightSkyBlue;
            this.bunifuFlatButton1.OnHoverTextColor = System.Drawing.Color.White;
            this.bunifuFlatButton1.selected = false;
            this.bunifuFlatButton1.Size = new System.Drawing.Size(232, 30);
            this.bunifuFlatButton1.TabIndex = 8;
            this.bunifuFlatButton1.Text = "LogIn";
            this.bunifuFlatButton1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuFlatButton1.Textcolor = System.Drawing.Color.White;
            this.bunifuFlatButton1.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuFlatButton1.Click += new System.EventHandler(this.bunifuFlatButton1_Click);
            // 
            // lblRegister
            // 
            this.lblRegister.AutoSize = true;
            this.lblRegister.Font = new System.Drawing.Font("Corbel", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegister.ForeColor = System.Drawing.Color.White;
            this.lblRegister.Location = new System.Drawing.Point(187, 433);
            this.lblRegister.Name = "lblRegister";
            this.lblRegister.Size = new System.Drawing.Size(88, 26);
            this.lblRegister.TabIndex = 5;
            this.lblRegister.Text = "Register";
            this.lblRegister.Click += new System.EventHandler(this.lblRegister_Click);
            // 
            // panel_register
            // 
            this.panel_register.Controls.Add(this.txtcomCpass);
            this.panel_register.Controls.Add(this.pictureBox4);
            this.panel_register.Controls.Add(this.txtcomPass);
            this.panel_register.Controls.Add(this.txtcomEmail);
            this.panel_register.Controls.Add(this.txtcountry);
            this.panel_register.Controls.Add(this.txtprovince);
            this.panel_register.Controls.Add(this.txtcity);
            this.panel_register.Controls.Add(this.txtaltPhone);
            this.panel_register.Controls.Add(this.txtphone);
            this.panel_register.Controls.Add(this.label6);
            this.panel_register.Controls.Add(this.label5);
            this.panel_register.Controls.Add(this.txtLastName);
            this.panel_register.Controls.Add(this.txtfname);
            this.panel_register.Controls.Add(this.txtcompanyName);
            this.panel_register.Controls.Add(this.btnSignup);
            this.panel_register.Controls.Add(this.lblLogIn);
            this.panel_register.Location = new System.Drawing.Point(7, 37);
            this.panel_register.Name = "panel_register";
            this.panel_register.Size = new System.Drawing.Size(314, 526);
            this.panel_register.TabIndex = 8;
            // 
            // txtcomCpass
            // 
            this.txtcomCpass.BorderColorFocused = System.Drawing.Color.LightSkyBlue;
            this.txtcomCpass.BorderColorIdle = System.Drawing.Color.LightSkyBlue;
            this.txtcomCpass.BorderColorMouseHover = System.Drawing.Color.DeepSkyBlue;
            this.txtcomCpass.BorderThickness = 3;
            this.txtcomCpass.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtcomCpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtcomCpass.ForeColor = System.Drawing.Color.White;
            this.txtcomCpass.isPassword = true;
            this.txtcomCpass.Location = new System.Drawing.Point(12, 342);
            this.txtcomCpass.Margin = new System.Windows.Forms.Padding(4);
            this.txtcomCpass.Name = "txtcomCpass";
            this.txtcomCpass.Size = new System.Drawing.Size(277, 31);
            this.txtcomCpass.TabIndex = 9;
            this.txtcomCpass.Text = "Confirm Password";
            this.txtcomCpass.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtcomCpass.Enter += new System.EventHandler(this.txtcomCpass_Enter);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(12, 19);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(58, 53);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 6;
            this.pictureBox4.TabStop = false;
            // 
            // txtcomPass
            // 
            this.txtcomPass.BorderColorFocused = System.Drawing.Color.LightSkyBlue;
            this.txtcomPass.BorderColorIdle = System.Drawing.Color.LightSkyBlue;
            this.txtcomPass.BorderColorMouseHover = System.Drawing.Color.DeepSkyBlue;
            this.txtcomPass.BorderThickness = 3;
            this.txtcomPass.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtcomPass.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtcomPass.ForeColor = System.Drawing.Color.White;
            this.txtcomPass.isPassword = true;
            this.txtcomPass.Location = new System.Drawing.Point(12, 303);
            this.txtcomPass.Margin = new System.Windows.Forms.Padding(4);
            this.txtcomPass.Name = "txtcomPass";
            this.txtcomPass.Size = new System.Drawing.Size(277, 31);
            this.txtcomPass.TabIndex = 9;
            this.txtcomPass.Text = "Passowrd";
            this.txtcomPass.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtcomPass.Enter += new System.EventHandler(this.txtcomPass_Enter);
            // 
            // txtcomEmail
            // 
            this.txtcomEmail.BorderColorFocused = System.Drawing.Color.LightSkyBlue;
            this.txtcomEmail.BorderColorIdle = System.Drawing.Color.LightSkyBlue;
            this.txtcomEmail.BorderColorMouseHover = System.Drawing.Color.DeepSkyBlue;
            this.txtcomEmail.BorderThickness = 3;
            this.txtcomEmail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtcomEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtcomEmail.ForeColor = System.Drawing.Color.White;
            this.txtcomEmail.isPassword = false;
            this.txtcomEmail.Location = new System.Drawing.Point(12, 266);
            this.txtcomEmail.Margin = new System.Windows.Forms.Padding(4);
            this.txtcomEmail.Name = "txtcomEmail";
            this.txtcomEmail.Size = new System.Drawing.Size(277, 31);
            this.txtcomEmail.TabIndex = 9;
            this.txtcomEmail.Text = "Email";
            this.txtcomEmail.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtcomEmail.Enter += new System.EventHandler(this.txtcomEmail_Enter);
            // 
            // txtcountry
            // 
            this.txtcountry.BorderColorFocused = System.Drawing.Color.LightSkyBlue;
            this.txtcountry.BorderColorIdle = System.Drawing.Color.LightSkyBlue;
            this.txtcountry.BorderColorMouseHover = System.Drawing.Color.DeepSkyBlue;
            this.txtcountry.BorderThickness = 3;
            this.txtcountry.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtcountry.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtcountry.ForeColor = System.Drawing.Color.White;
            this.txtcountry.isPassword = false;
            this.txtcountry.Location = new System.Drawing.Point(194, 230);
            this.txtcountry.Margin = new System.Windows.Forms.Padding(4);
            this.txtcountry.Name = "txtcountry";
            this.txtcountry.Size = new System.Drawing.Size(93, 31);
            this.txtcountry.TabIndex = 9;
            this.txtcountry.Text = "Country";
            this.txtcountry.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtcountry.Enter += new System.EventHandler(this.txtcountry_Enter);
            // 
            // txtprovince
            // 
            this.txtprovince.BorderColorFocused = System.Drawing.Color.LightSkyBlue;
            this.txtprovince.BorderColorIdle = System.Drawing.Color.LightSkyBlue;
            this.txtprovince.BorderColorMouseHover = System.Drawing.Color.DeepSkyBlue;
            this.txtprovince.BorderThickness = 3;
            this.txtprovince.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtprovince.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtprovince.ForeColor = System.Drawing.Color.White;
            this.txtprovince.isPassword = false;
            this.txtprovince.Location = new System.Drawing.Point(101, 230);
            this.txtprovince.Margin = new System.Windows.Forms.Padding(4);
            this.txtprovince.Name = "txtprovince";
            this.txtprovince.Size = new System.Drawing.Size(94, 31);
            this.txtprovince.TabIndex = 9;
            this.txtprovince.Text = "Province";
            this.txtprovince.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtprovince.Enter += new System.EventHandler(this.txtprovince_Enter);
            // 
            // txtcity
            // 
            this.txtcity.BorderColorFocused = System.Drawing.Color.LightSkyBlue;
            this.txtcity.BorderColorIdle = System.Drawing.Color.LightSkyBlue;
            this.txtcity.BorderColorMouseHover = System.Drawing.Color.DeepSkyBlue;
            this.txtcity.BorderThickness = 3;
            this.txtcity.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtcity.ForeColor = System.Drawing.Color.White;
            this.txtcity.isPassword = false;
            this.txtcity.Location = new System.Drawing.Point(12, 230);
            this.txtcity.Margin = new System.Windows.Forms.Padding(4);
            this.txtcity.Name = "txtcity";
            this.txtcity.Size = new System.Drawing.Size(90, 31);
            this.txtcity.TabIndex = 9;
            this.txtcity.Text = "City";
            this.txtcity.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtcity.Enter += new System.EventHandler(this.txtcity_Enter);
            // 
            // txtaltPhone
            // 
            this.txtaltPhone.BorderColorFocused = System.Drawing.Color.LightSkyBlue;
            this.txtaltPhone.BorderColorIdle = System.Drawing.Color.LightSkyBlue;
            this.txtaltPhone.BorderColorMouseHover = System.Drawing.Color.DeepSkyBlue;
            this.txtaltPhone.BorderThickness = 3;
            this.txtaltPhone.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtaltPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtaltPhone.ForeColor = System.Drawing.Color.White;
            this.txtaltPhone.isPassword = false;
            this.txtaltPhone.Location = new System.Drawing.Point(150, 195);
            this.txtaltPhone.Margin = new System.Windows.Forms.Padding(4);
            this.txtaltPhone.Name = "txtaltPhone";
            this.txtaltPhone.Size = new System.Drawing.Size(139, 31);
            this.txtaltPhone.TabIndex = 9;
            this.txtaltPhone.Text = "Alternate Phone";
            this.txtaltPhone.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtaltPhone.Enter += new System.EventHandler(this.bunifuMetroTextbox1_Enter);
            // 
            // txtphone
            // 
            this.txtphone.BorderColorFocused = System.Drawing.Color.LightSkyBlue;
            this.txtphone.BorderColorIdle = System.Drawing.Color.LightSkyBlue;
            this.txtphone.BorderColorMouseHover = System.Drawing.Color.DeepSkyBlue;
            this.txtphone.BorderThickness = 3;
            this.txtphone.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtphone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtphone.ForeColor = System.Drawing.Color.White;
            this.txtphone.isPassword = false;
            this.txtphone.Location = new System.Drawing.Point(12, 195);
            this.txtphone.Margin = new System.Windows.Forms.Padding(4);
            this.txtphone.Name = "txtphone";
            this.txtphone.Size = new System.Drawing.Size(129, 31);
            this.txtphone.TabIndex = 9;
            this.txtphone.Text = "Phone";
            this.txtphone.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtphone.Enter += new System.EventHandler(this.txtphone_Enter);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Corbel", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(70, 47);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(145, 26);
            this.label6.TabIndex = 5;
            this.label6.Text = "New Company";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Corbel", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(71, 22);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(88, 26);
            this.label5.TabIndex = 5;
            this.label5.Text = "Register";
            // 
            // txtLastName
            // 
            this.txtLastName.BorderColorFocused = System.Drawing.Color.LightSkyBlue;
            this.txtLastName.BorderColorIdle = System.Drawing.Color.LightSkyBlue;
            this.txtLastName.BorderColorMouseHover = System.Drawing.Color.DeepSkyBlue;
            this.txtLastName.BorderThickness = 3;
            this.txtLastName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtLastName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtLastName.ForeColor = System.Drawing.Color.White;
            this.txtLastName.isPassword = false;
            this.txtLastName.Location = new System.Drawing.Point(150, 156);
            this.txtLastName.Margin = new System.Windows.Forms.Padding(4);
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(139, 31);
            this.txtLastName.TabIndex = 9;
            this.txtLastName.Text = "Last Name";
            this.txtLastName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtLastName.Enter += new System.EventHandler(this.txtLastName_Enter);
            // 
            // txtfname
            // 
            this.txtfname.BorderColorFocused = System.Drawing.Color.LightSkyBlue;
            this.txtfname.BorderColorIdle = System.Drawing.Color.LightSkyBlue;
            this.txtfname.BorderColorMouseHover = System.Drawing.Color.DeepSkyBlue;
            this.txtfname.BorderThickness = 3;
            this.txtfname.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtfname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtfname.ForeColor = System.Drawing.Color.White;
            this.txtfname.isPassword = false;
            this.txtfname.Location = new System.Drawing.Point(12, 156);
            this.txtfname.Margin = new System.Windows.Forms.Padding(4);
            this.txtfname.Name = "txtfname";
            this.txtfname.Size = new System.Drawing.Size(129, 31);
            this.txtfname.TabIndex = 9;
            this.txtfname.Text = "First Name";
            this.txtfname.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtfname.Enter += new System.EventHandler(this.txtfname_Enter);
            // 
            // txtcompanyName
            // 
            this.txtcompanyName.BorderColorFocused = System.Drawing.Color.LightSkyBlue;
            this.txtcompanyName.BorderColorIdle = System.Drawing.Color.LightSkyBlue;
            this.txtcompanyName.BorderColorMouseHover = System.Drawing.Color.DeepSkyBlue;
            this.txtcompanyName.BorderThickness = 3;
            this.txtcompanyName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtcompanyName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtcompanyName.ForeColor = System.Drawing.Color.White;
            this.txtcompanyName.isPassword = false;
            this.txtcompanyName.Location = new System.Drawing.Point(12, 117);
            this.txtcompanyName.Margin = new System.Windows.Forms.Padding(4);
            this.txtcompanyName.Name = "txtcompanyName";
            this.txtcompanyName.Size = new System.Drawing.Size(279, 31);
            this.txtcompanyName.TabIndex = 9;
            this.txtcompanyName.Text = "Company Name";
            this.txtcompanyName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtcompanyName.Enter += new System.EventHandler(this.txtcompanyName_Enter);
            // 
            // btnSignup
            // 
            this.btnSignup.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(139)))), ((int)(((byte)(87)))));
            this.btnSignup.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnSignup.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSignup.BorderRadius = 0;
            this.btnSignup.ButtonText = "SignUp";
            this.btnSignup.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSignup.DisabledColor = System.Drawing.Color.Gray;
            this.btnSignup.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSignup.Iconcolor = System.Drawing.Color.Transparent;
            this.btnSignup.Iconimage = null;
            this.btnSignup.Iconimage_right = null;
            this.btnSignup.Iconimage_right_Selected = null;
            this.btnSignup.Iconimage_Selected = null;
            this.btnSignup.IconMarginLeft = 0;
            this.btnSignup.IconMarginRight = 0;
            this.btnSignup.IconRightVisible = true;
            this.btnSignup.IconRightZoom = 0D;
            this.btnSignup.IconVisible = true;
            this.btnSignup.IconZoom = 90D;
            this.btnSignup.IsTab = false;
            this.btnSignup.Location = new System.Drawing.Point(12, 391);
            this.btnSignup.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSignup.Name = "btnSignup";
            this.btnSignup.Normalcolor = System.Drawing.Color.DodgerBlue;
            this.btnSignup.OnHovercolor = System.Drawing.Color.LightSkyBlue;
            this.btnSignup.OnHoverTextColor = System.Drawing.Color.White;
            this.btnSignup.selected = false;
            this.btnSignup.Size = new System.Drawing.Size(279, 30);
            this.btnSignup.TabIndex = 8;
            this.btnSignup.Text = "SignUp";
            this.btnSignup.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSignup.Textcolor = System.Drawing.Color.White;
            this.btnSignup.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSignup.Click += new System.EventHandler(this.btnSignup_Click);
            // 
            // lblLogIn
            // 
            this.lblLogIn.AutoSize = true;
            this.lblLogIn.Font = new System.Drawing.Font("Corbel", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogIn.ForeColor = System.Drawing.Color.White;
            this.lblLogIn.Location = new System.Drawing.Point(224, 439);
            this.lblLogIn.Name = "lblLogIn";
            this.lblLogIn.Size = new System.Drawing.Size(65, 26);
            this.lblLogIn.TabIndex = 5;
            this.lblLogIn.Text = "LogIn";
            this.lblLogIn.Click += new System.EventHandler(this.lblLogIn_Click);
            // 
            // frmlogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(28)))), ((int)(((byte)(38)))));
            this.ClientSize = new System.Drawing.Size(329, 576);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panellogin);
            this.Controls.Add(this.panel_register);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmlogin";
            this.Opacity = 0.9D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmlogin";
            this.Load += new System.EventHandler(this.frmlogin_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panellogin.ResumeLayout(false);
            this.panellogin.PerformLayout();
            this.panel_register.ResumeLayout(false);
            this.panel_register.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private Bunifu.Framework.UI.BunifuDropdown cbotype;
        private System.Windows.Forms.PictureBox pictureBox1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtemail;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel_register;
        private System.Windows.Forms.Label lblLogIn;
        private System.Windows.Forms.Panel panellogin;
        private Bunifu.Framework.UI.BunifuFlatButton bunifuFlatButton1;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtcomCpass;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtcomPass;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtcomEmail;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtphone;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtLastName;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtfname;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtcompanyName;
        private Bunifu.Framework.UI.BunifuFlatButton btnSignup;
        private System.Windows.Forms.Label lblRegister;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtpass;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtcountry;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtprovince;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtcity;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtaltPhone;
    }
}