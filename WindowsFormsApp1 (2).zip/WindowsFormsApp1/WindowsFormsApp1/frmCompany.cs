﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;
using System.Drawing.Imaging;

namespace WindowsFormsApp1
{
    public partial class frmCompany : Form
    {
        clsConnection obj = new clsConnection();
        public frmCompany()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Close();

        }
        private void clearObjects()
        {
            txtcode.Text = "";
            txtcompanyName.Text = "";
            txtphone.Text = "";
            txtaltPhone.Text = "";
            txtfName.Text = "";
            txtcity.Text = "";
            cboCountry.Text = "";
            cboProvince.Text = "";
            txtpassword.Text = "";
            txtemail.Text = "";
        }
        private void bunifuThinButton21_Click(object sender, EventArgs e)
        {
            if (txtcode.Text == "")
            {
                MessageBox.Show("Enter Company Code!");
                txtcode.Focus();
                return;
            }
            if (txtcompanyName.Text == "")
            {
                MessageBox.Show("Enter Company Name!");
                txtcompanyName.Focus();
                return;
            }
            if (txtfName.Text == "")
            {
                MessageBox.Show("Enter Full Name!");
                txtfName.Focus();
                return;
            }
            if (txtphone.Text == "")
            {
                MessageBox.Show("Enter Company phone!");
                txtphone.Focus();
                return;
            }
            if (txtaltPhone.Text == "")
            {
                MessageBox.Show("Enter alternate phone!");
                txtaltPhone.Focus();
                return;
            }
            if (txtemail.Text == "")
            {
                MessageBox.Show("Enter Company Email!");
                txtemail.Focus();
                return;
            }
            if (txtpassword.Text == "")
            {
                MessageBox.Show("Enter Passowrd!");
                txtpassword.Focus();
                return;
            }
            if (txtcity.Text == "")
            {
                MessageBox.Show("Enter City!");
                txtcity.Focus();
                return;
            }
            if (cboProvince.Text == "")
            {
                MessageBox.Show("Enter Company Province!");
                cboProvince.Focus();
                return;
            }
            if (cboCountry.Text == "")
            {
                MessageBox.Show("Enter Company Country!");
                cboCountry.Focus();
                return;
            }

            System.Text.RegularExpressions.Regex rEMail = new System.Text.RegularExpressions.Regex(@"^[a-zA-Z][\w\.-]{2,28}[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$");
            if (txtemail.Text.Length > 0)
            {
                if (!rEMail.IsMatch(txtemail.Text))
                {
                    MessageBox.Show("E-Mail expected", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtemail.Text = "";
                    txtemail.Focus();
                    return;
                }
            }
            if (!is_record_exist(txtcode.Text))
            {
                add_record();
                add_user();
                delete_record();
                MessageBox.Show("Record Successfully Added!");
            }
            else
            {
                if (MessageBox.Show("Do you want to update?", "User Info", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    Update_record();
                    MessageBox.Show("Record Successfully Updated!");
                }
            }
            clearObjects();
        }
        private void add_record()
        {
            MemoryStream ms = new MemoryStream();
            pictureBox6.Image.Save(ms, ImageFormat.Jpeg);
            byte[] photo_aray = new byte[ms.Length];
            ms.Position = 0;
            ms.Read(photo_aray, 0, photo_aray.Length);

            MySqlCommand cmd = new MySqlCommand();
            MySqlParameter prm = new MySqlParameter();
            String sql = "Insert into companies (code,company_name,City,Province,Country,admin,Manager,Phone,Alt_phone,email,active,Logo,reg_date )";
            sql += " values(@code,@company_name,@City,@Province,@Country,@admin,@Manager,@Phone,@Alt_phone,@email,@active,@Logo,@reg_date)";
            obj.conn_open();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = obj.cnn;
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@code", Convert.ToInt32(txtcode.Text));
            cmd.Parameters.AddWithValue("@company_name", txtcompanyName.Text);
            cmd.Parameters.AddWithValue("@City", txtcity.Text);
            cmd.Parameters.AddWithValue("@Province", cboProvince.Text);
            cmd.Parameters.AddWithValue("@Country", cboCountry.Text);
            cmd.Parameters.AddWithValue("@admin", clsConnection.Adminid);
            cmd.Parameters.AddWithValue("@Manager", txtfName.Text);
            cmd.Parameters.AddWithValue("@Phone", txtphone.Text);// DateTime.Now;
            cmd.Parameters.AddWithValue("@Alt_phone", txtaltPhone.Text);
            cmd.Parameters.AddWithValue("@email", txtemail.Text);
            if(chk_isActive.Checked == true)
            {
                cmd.Parameters.AddWithValue("@active", "Yes");
            }
            else
            {
                cmd.Parameters.AddWithValue("@active", "No");
            }
            cmd.Parameters.AddWithValue("@Logo", photo_aray);
            cmd.Parameters.AddWithValue("@reg_date", DateTime.Now);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            obj.conn_close();
        }
        private void Update_record()
        {
            MemoryStream ms = new MemoryStream();
            pictureBox6.Image.Save(ms, ImageFormat.Jpeg);
            byte[] photo_aray = new byte[ms.Length];
            ms.Position = 0;
            ms.Read(photo_aray, 0, photo_aray.Length);

            MySqlCommand cmd = new MySqlCommand();
            MySqlParameter prm = new MySqlParameter();
            String sql = "update companies set company_name=@company_name,City=@City,Province=@Province,Country=@Country,admin=@admin,Manager=@Manager," +
                "Phone=@Phone,Alt_phone=@Alt_phone,email=@email,active=@active,Logo=@Logo,reg_date=@reg_date where code=@code";

            obj.conn_open();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = obj.cnn;
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@code", Convert.ToInt32(txtcode.Text));
            cmd.Parameters.AddWithValue("@company_name", txtcompanyName.Text);
            cmd.Parameters.AddWithValue("@City", txtcity.Text);
            cmd.Parameters.AddWithValue("@Province", cboProvince.Text);
            cmd.Parameters.AddWithValue("@Country", cboCountry.Text);
            cmd.Parameters.AddWithValue("@admin", clsConnection.Adminid);
            cmd.Parameters.AddWithValue("@Manager", txtfName.Text);
            cmd.Parameters.AddWithValue("@Phone", txtphone.Text);// DateTime.Now;
            cmd.Parameters.AddWithValue("@Alt_phone", txtaltPhone.Text);
            cmd.Parameters.AddWithValue("@email", txtemail.Text);
            if (chk_isActive.Checked == true)
            {
                cmd.Parameters.AddWithValue("@active", "Yes");
            }
            else
            {
                cmd.Parameters.AddWithValue("@active", "No");
            }
            cmd.Parameters.AddWithValue("@Logo", photo_aray);
            cmd.Parameters.AddWithValue("@reg_date", DateTime.Now);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            obj.conn_close();
        }
        private bool is_record_exist(String id)
        {
            obj.conn_open();
            String sql = "Select * from companies where code='" + id + "'";
            MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
            MySqlDataReader dr;
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                dr.Dispose();
                obj.conn_close();
                return true;
            }
            else
            {
                dr.Dispose();
                obj.conn_close();
                return false;
            }
        }
        private void add_user()
        {
            MemoryStream ms = new MemoryStream();
            pictureBox6.Image.Save(ms, ImageFormat.Jpeg);
            byte[] photo_aray = new byte[ms.Length];
            ms.Position = 0;
            ms.Read(photo_aray, 0, photo_aray.Length);

            MySqlCommand cmd = new MySqlCommand();
            MySqlParameter prm = new MySqlParameter();
            String sql = "Insert into company_users (Email,pass,Hint,photo,Date,code,Role,userName)";
            sql += " values(@Email,@pass,@Hint,@photo,@Date,@code,@Role,@userName)";
            obj.conn_open();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = obj.cnn;
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@Email", txtemail.Text);
            cmd.Parameters.AddWithValue("@pass", txtpassword.Text);
            cmd.Parameters.AddWithValue("@Hint", txtpassword.Text.Substring(0,2));
            cmd.Parameters.AddWithValue("@photo", photo_aray);
            cmd.Parameters.AddWithValue("@Date", DateTime.Now);
            cmd.Parameters.AddWithValue("@code", txtcode.Text);
            cmd.Parameters.AddWithValue("@userName", txtfName.Text.Substring(0,txtfName.Text.IndexOf(' ')));
            cmd.Parameters.AddWithValue("@Role", "Admin");

            cmd.ExecuteNonQuery();
            cmd.Dispose();
            obj.conn_close();
        }
        private void delete_record()
        {
            MySqlCommand cmd = new MySqlCommand();
            MySqlParameter prm = new MySqlParameter();
            String sql = "delete from companyrequests where company_name=@company_name and phone=@phone ";
            obj.conn_open();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = obj.cnn;
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@company_name",txtcompanyName.Text);
            cmd.Parameters.AddWithValue("@phone", txtphone.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            obj.conn_close();
        }
        private void frmCompany_Load(object sender, EventArgs e)
        {
            fill_grid();
            //dataGridView1.Visible = false;
            papulate_dropdown();
            papulate_cboprovince();
            chk_isActive.Checked = true;
        }
        private void papulate_dropdown()
        {
            String sql = "select * from countries";
            obj.conn_open();
            MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
            MySqlDataReader dr;
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                cboCountry.Items.Add(dr[0].ToString());
            }
            dr.Dispose();
            obj.conn_close();
        }
        private void papulate_cboprovince()
        {
            String sql = "select * from company_codes";
            obj.conn_open();
            MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
            MySqlDataReader dr;
            dr = cmd.ExecuteReader();

            while (dr.Read())
            {
                //cboProvince.AddItem(dr[1].ToString());
                cboProvince.Items.Add(dr[1].ToString());
            }
            dr.Dispose();
            obj.conn_close();
        }
        private void fill_grid()
        {
            obj.conn_open();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = obj.cnn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from companyrequests";
            MySqlDataAdapter sqlDataAdap = new MySqlDataAdapter(cmd);

            DataTable dtRecord = new DataTable();
            sqlDataAdap.Fill(dtRecord);
            //dataGridView1.DataSource = dtRecord;
            obj.conn_close();
        }

        private void cboProvince_MouseHover(object sender, EventArgs e)
        {
            panel2.BackColor = Color.DodgerBlue;
        }

        private void cboProvince_Enter(object sender, EventArgs e)
        {
            panel2.BackColor = Color.CornflowerBlue;
        }

        private void cboCountry_Enter(object sender, EventArgs e)
        {
            panel4.BackColor = Color.CornflowerBlue;
        }

        private void cboCountry_MouseHover(object sender, EventArgs e)
        {
            panel4.BackColor = Color.DodgerBlue;
        }

        private void cboCountry_MouseLeave(object sender, EventArgs e)
        {
            panel4.BackColor = Color.DarkBlue;
        }

        private void cboProvince_MouseLeave(object sender, EventArgs e)
        {
            panel2.BackColor = Color.DarkBlue;
        }

        private void txtpassword_MouseHover(object sender, EventArgs e)
        {
            panel5.BackColor = Color.DodgerBlue;
        }

        private void txtpassword_MouseLeave(object sender, EventArgs e)
        {
            panel5.BackColor = Color.DarkBlue;
        }

        private void txtpassword_Enter(object sender, EventArgs e)
        {
            panel5.BackColor = Color.CornflowerBlue;
        }

        private void btnGenreate_Click(object sender, EventArgs e)
        {
            String sql = "select max(code) as code from companies where Province='"+ cboProvince.Text + "'";
            obj.conn_open();
            MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
            MySqlDataReader dr;
            dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                if (dr[0] != DBNull.Value)
                {
                    txtcode.Text = (Convert.ToInt32(dr[0]) + 1).ToString();
                    dr.Dispose();
                    obj.conn_close();
                }
                else
                {
                    dr.Dispose();
                    obj.conn_close();
                    read_new_code();
                }
                
            }
            
            
        }
        private void read_new_code()
        {
            String sql = "select * from company_codes where province='" + cboProvince.Text + "'";
            obj.conn_open();
            MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
            MySqlDataReader dr;
            dr = cmd.ExecuteReader();

            if (dr.Read())
            {
                txtcode.Text = dr[0].ToString();
            }
            dr.Dispose();
            obj.conn_close();
        }

        private void txtcode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                obj.conn_open();
                String sql = "Select * from companies where code='" + txtcode.Text + "'";
                MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
                MySqlDataReader dr;
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    txtcode.Text = dr[0].ToString();
                    txtcompanyName.Text = dr[1].ToString();
                    txtcity.Text = dr[2].ToString();
                    cboProvince.Text = dr[3].ToString();
                    cboCountry.Text = dr[4].ToString();
                    txtfName.Text = dr[6].ToString();
                    txtphone.Text = dr[7].ToString();
                    txtaltPhone.Text = dr[8].ToString();
                    txtemail.Text = dr[9].ToString();
                    //if (dr[10].)
                    chk_isActive.Checked = Convert.ToBoolean(Convert.ToInt16(dr[10]));

                }
                dr.Dispose();
                obj.conn_close();
            }
        }
    }
}
