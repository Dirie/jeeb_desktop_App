﻿namespace WindowsFormsApp1
{
    partial class frmTransactions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTransactions));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.txtfrom = new System.Windows.Forms.TextBox();
            this.txtAccountNoFrom = new System.Windows.Forms.TextBox();
            this.panelFrom = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.pbfrom = new System.Windows.Forms.PictureBox();
            this.txtFromName = new System.Windows.Forms.TextBox();
            this.txtFromCode = new System.Windows.Forms.TextBox();
            this.txtFromBalance = new System.Windows.Forms.TextBox();
            this.panelTo = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.pbTo = new System.Windows.Forms.PictureBox();
            this.txtToName = new System.Windows.Forms.TextBox();
            this.txtToCode = new System.Windows.Forms.TextBox();
            this.txtToBalance = new System.Windows.Forms.TextBox();
            this.txtAccountNoTo = new System.Windows.Forms.TextBox();
            this.lblfrom = new System.Windows.Forms.Label();
            this.lblTo = new System.Windows.Forms.Label();
            this.txtTo = new System.Windows.Forms.TextBox();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.txtRefrence = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.cbotranType = new System.Windows.Forms.ComboBox();
            this.label15 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.btnSave = new Bunifu.Framework.UI.BunifuThinButton2();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panelFrom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbfrom)).BeginInit();
            this.panelTo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbTo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Location = new System.Drawing.Point(105, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(746, 35);
            this.panel1.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(721, -1);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "X";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(161, 6);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(222, 24);
            this.label16.TabIndex = 7;
            this.label16.Text = "TRANSACTION FORM";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(27, -3);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(79, 75);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 5;
            this.pictureBox2.TabStop = false;
            // 
            // txtfrom
            // 
            this.txtfrom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtfrom.Location = new System.Drawing.Point(82, 139);
            this.txtfrom.Name = "txtfrom";
            this.txtfrom.Size = new System.Drawing.Size(238, 20);
            this.txtfrom.TabIndex = 6;
            this.txtfrom.TextChanged += new System.EventHandler(this.txtfrom_TextChanged);
            // 
            // txtAccountNoFrom
            // 
            this.txtAccountNoFrom.Location = new System.Drawing.Point(82, 21);
            this.txtAccountNoFrom.Name = "txtAccountNoFrom";
            this.txtAccountNoFrom.ReadOnly = true;
            this.txtAccountNoFrom.Size = new System.Drawing.Size(187, 20);
            this.txtAccountNoFrom.TabIndex = 6;
            // 
            // panelFrom
            // 
            this.panelFrom.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelFrom.Controls.Add(this.label5);
            this.panelFrom.Controls.Add(this.label4);
            this.panelFrom.Controls.Add(this.label3);
            this.panelFrom.Controls.Add(this.label2);
            this.panelFrom.Controls.Add(this.pbfrom);
            this.panelFrom.Controls.Add(this.txtFromName);
            this.panelFrom.Controls.Add(this.txtFromCode);
            this.panelFrom.Controls.Add(this.txtFromBalance);
            this.panelFrom.Controls.Add(this.txtAccountNoFrom);
            this.panelFrom.Location = new System.Drawing.Point(32, 176);
            this.panelFrom.Name = "panelFrom";
            this.panelFrom.Size = new System.Drawing.Size(380, 143);
            this.panelFrom.TabIndex = 7;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(203, 107);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 16);
            this.label5.TabIndex = 7;
            this.label5.Text = "Balance";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(314, 78);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 16);
            this.label4.TabIndex = 7;
            this.label4.Text = "Name";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(275, 49);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(45, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = "Code";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(275, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "Account No";
            // 
            // pbfrom
            // 
            this.pbfrom.Location = new System.Drawing.Point(8, 6);
            this.pbfrom.Name = "pbfrom";
            this.pbfrom.Size = new System.Drawing.Size(68, 64);
            this.pbfrom.TabIndex = 0;
            this.pbfrom.TabStop = false;
            // 
            // txtFromName
            // 
            this.txtFromName.Location = new System.Drawing.Point(10, 75);
            this.txtFromName.Name = "txtFromName";
            this.txtFromName.ReadOnly = true;
            this.txtFromName.Size = new System.Drawing.Size(298, 20);
            this.txtFromName.TabIndex = 6;
            // 
            // txtFromCode
            // 
            this.txtFromCode.Location = new System.Drawing.Point(82, 47);
            this.txtFromCode.Name = "txtFromCode";
            this.txtFromCode.ReadOnly = true;
            this.txtFromCode.Size = new System.Drawing.Size(187, 20);
            this.txtFromCode.TabIndex = 6;
            // 
            // txtFromBalance
            // 
            this.txtFromBalance.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFromBalance.Location = new System.Drawing.Point(10, 102);
            this.txtFromBalance.Name = "txtFromBalance";
            this.txtFromBalance.ReadOnly = true;
            this.txtFromBalance.Size = new System.Drawing.Size(187, 30);
            this.txtFromBalance.TabIndex = 6;
            // 
            // panelTo
            // 
            this.panelTo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelTo.Controls.Add(this.label6);
            this.panelTo.Controls.Add(this.label7);
            this.panelTo.Controls.Add(this.label8);
            this.panelTo.Controls.Add(this.label9);
            this.panelTo.Controls.Add(this.pbTo);
            this.panelTo.Controls.Add(this.txtToName);
            this.panelTo.Controls.Add(this.txtToCode);
            this.panelTo.Controls.Add(this.txtToBalance);
            this.panelTo.Controls.Add(this.txtAccountNoTo);
            this.panelTo.Location = new System.Drawing.Point(443, 176);
            this.panelTo.Name = "panelTo";
            this.panelTo.Size = new System.Drawing.Size(380, 143);
            this.panelTo.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(203, 107);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(65, 16);
            this.label6.TabIndex = 7;
            this.label6.Text = "Balance";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(314, 78);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 16);
            this.label7.TabIndex = 7;
            this.label7.Text = "Name";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(275, 51);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(45, 16);
            this.label8.TabIndex = 7;
            this.label8.Text = "Code";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(275, 24);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(87, 16);
            this.label9.TabIndex = 7;
            this.label9.Text = "Account No";
            // 
            // pbTo
            // 
            this.pbTo.Location = new System.Drawing.Point(7, 4);
            this.pbTo.Name = "pbTo";
            this.pbTo.Size = new System.Drawing.Size(70, 66);
            this.pbTo.TabIndex = 0;
            this.pbTo.TabStop = false;
            // 
            // txtToName
            // 
            this.txtToName.Location = new System.Drawing.Point(10, 75);
            this.txtToName.Name = "txtToName";
            this.txtToName.ReadOnly = true;
            this.txtToName.Size = new System.Drawing.Size(298, 20);
            this.txtToName.TabIndex = 6;
            // 
            // txtToCode
            // 
            this.txtToCode.Location = new System.Drawing.Point(82, 47);
            this.txtToCode.Name = "txtToCode";
            this.txtToCode.ReadOnly = true;
            this.txtToCode.Size = new System.Drawing.Size(187, 20);
            this.txtToCode.TabIndex = 6;
            // 
            // txtToBalance
            // 
            this.txtToBalance.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtToBalance.Location = new System.Drawing.Point(10, 102);
            this.txtToBalance.Name = "txtToBalance";
            this.txtToBalance.ReadOnly = true;
            this.txtToBalance.Size = new System.Drawing.Size(187, 30);
            this.txtToBalance.TabIndex = 6;
            // 
            // txtAccountNoTo
            // 
            this.txtAccountNoTo.Location = new System.Drawing.Point(82, 21);
            this.txtAccountNoTo.Name = "txtAccountNoTo";
            this.txtAccountNoTo.ReadOnly = true;
            this.txtAccountNoTo.Size = new System.Drawing.Size(187, 20);
            this.txtAccountNoTo.TabIndex = 6;
            // 
            // lblfrom
            // 
            this.lblfrom.AutoSize = true;
            this.lblfrom.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfrom.Location = new System.Drawing.Point(33, 139);
            this.lblfrom.Name = "lblfrom";
            this.lblfrom.Size = new System.Drawing.Size(43, 16);
            this.lblfrom.TabIndex = 7;
            this.lblfrom.Text = "From";
            // 
            // lblTo
            // 
            this.lblTo.AutoSize = true;
            this.lblTo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTo.Location = new System.Drawing.Point(464, 139);
            this.lblTo.Name = "lblTo";
            this.lblTo.Size = new System.Drawing.Size(31, 16);
            this.lblTo.TabIndex = 7;
            this.lblTo.Text = "To:";
            // 
            // txtTo
            // 
            this.txtTo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTo.Location = new System.Drawing.Point(498, 138);
            this.txtTo.Name = "txtTo";
            this.txtTo.Size = new System.Drawing.Size(238, 20);
            this.txtTo.TabIndex = 6;
            this.txtTo.TextChanged += new System.EventHandler(this.txtTo_TextChanged);
            // 
            // txtAmount
            // 
            this.txtAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtAmount.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtAmount.Location = new System.Drawing.Point(115, 342);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(238, 30);
            this.txtAmount.TabIndex = 6;
            // 
            // txtRefrence
            // 
            this.txtRefrence.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtRefrence.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRefrence.Location = new System.Drawing.Point(115, 385);
            this.txtRefrence.Name = "txtRefrence";
            this.txtRefrence.Size = new System.Drawing.Size(708, 26);
            this.txtRefrence.TabIndex = 6;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(44, 347);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(63, 16);
            this.label12.TabIndex = 7;
            this.label12.Text = "Amount:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(32, 387);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(75, 16);
            this.label13.TabIndex = 7;
            this.label13.Text = "Refrence:";
            // 
            // cbotranType
            // 
            this.cbotranType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbotranType.FormattingEnabled = true;
            this.cbotranType.Items.AddRange(new object[] {
            "Deposit",
            "Withdrawl",
            "Transfere",
            "Remit"});
            this.cbotranType.Location = new System.Drawing.Point(180, 92);
            this.cbotranType.Name = "cbotranType";
            this.cbotranType.Size = new System.Drawing.Size(215, 21);
            this.cbotranType.TabIndex = 9;
            this.cbotranType.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(40, 92);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(134, 16);
            this.label15.TabIndex = 7;
            this.label15.Text = "Transaction Type:";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(508, 49);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(52, 40);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 5;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(570, 49);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(52, 40);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 5;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(630, 49);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(52, 40);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 5;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(692, 49);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(52, 40);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 5;
            this.pictureBox7.TabStop = false;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(515, 92);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(43, 13);
            this.label17.TabIndex = 10;
            this.label17.Text = "Deposit";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(568, 92);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(54, 13);
            this.label18.TabIndex = 10;
            this.label18.Text = "Withdrawl";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(632, 91);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(52, 13);
            this.label19.TabIndex = 10;
            this.label19.Text = "Transfere";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(704, 92);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(34, 13);
            this.label20.TabIndex = 10;
            this.label20.Text = "Remit";
            // 
            // btnSave
            // 
            this.btnSave.ActiveBorderThickness = 1;
            this.btnSave.ActiveCornerRadius = 20;
            this.btnSave.ActiveFillColor = System.Drawing.Color.LightSkyBlue;
            this.btnSave.ActiveForecolor = System.Drawing.Color.White;
            this.btnSave.ActiveLineColor = System.Drawing.Color.Indigo;
            this.btnSave.BackColor = System.Drawing.Color.White;
            this.btnSave.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSave.BackgroundImage")));
            this.btnSave.ButtonText = "Save";
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnSave.IdleBorderThickness = 1;
            this.btnSave.IdleCornerRadius = 20;
            this.btnSave.IdleFillColor = System.Drawing.Color.White;
            this.btnSave.IdleForecolor = System.Drawing.Color.MidnightBlue;
            this.btnSave.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnSave.Location = new System.Drawing.Point(601, 441);
            this.btnSave.Margin = new System.Windows.Forms.Padding(5);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(174, 48);
            this.btnSave.TabIndex = 12;
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // frmTransactions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(850, 515);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.cbotranType);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.panelTo);
            this.Controls.Add(this.panelFrom);
            this.Controls.Add(this.txtTo);
            this.Controls.Add(this.lblTo);
            this.Controls.Add(this.txtRefrence);
            this.Controls.Add(this.txtAmount);
            this.Controls.Add(this.txtfrom);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.lblfrom);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmTransactions";
            this.Text = "frmTransactions";
            this.Load += new System.EventHandler(this.frmTransactions_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panelFrom.ResumeLayout(false);
            this.panelFrom.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbfrom)).EndInit();
            this.panelTo.ResumeLayout(false);
            this.panelTo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbTo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox txtfrom;
        private System.Windows.Forms.TextBox txtAccountNoFrom;
        private System.Windows.Forms.Panel panelFrom;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pbfrom;
        private System.Windows.Forms.TextBox txtFromName;
        private System.Windows.Forms.TextBox txtFromCode;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtFromBalance;
        private System.Windows.Forms.Panel panelTo;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.PictureBox pbTo;
        private System.Windows.Forms.TextBox txtToName;
        private System.Windows.Forms.TextBox txtToCode;
        private System.Windows.Forms.TextBox txtToBalance;
        private System.Windows.Forms.TextBox txtAccountNoTo;
        private System.Windows.Forms.Label lblfrom;
        private System.Windows.Forms.Label lblTo;
        private System.Windows.Forms.TextBox txtTo;
        private System.Windows.Forms.TextBox txtAmount;
        private System.Windows.Forms.TextBox txtRefrence;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox cbotranType;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label16;
        private Bunifu.Framework.UI.BunifuThinButton2 btnSave;
    }
}