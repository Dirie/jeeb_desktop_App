﻿namespace WindowsFormsApp1
{
    partial class frmAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAdmin));
            this.panel2 = new System.Windows.Forms.Panel();
            this.cboCountry = new Bunifu.Framework.UI.BunifuDropdown();
            this.cbotype = new Bunifu.Framework.UI.BunifuDropdown();
            this.cboRole = new Bunifu.Framework.UI.BunifuDropdown();
            this.label11 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.datetimePicker = new Bunifu.Framework.UI.BunifuDatepicker();
            this.txtFName = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.txtdate = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.txtprovince = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.txtpob = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.txtcity = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.txtAltPhone = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.txtPhone = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.txtemail = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.txtId = new Bunifu.Framework.UI.BunifuMetroTextbox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnSave = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnNew = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.label13 = new System.Windows.Forms.Label();
            this.btnupdate = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.AutoSize = true;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.cboCountry);
            this.panel2.Controls.Add(this.cbotype);
            this.panel2.Controls.Add(this.cboRole);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.datetimePicker);
            this.panel2.Controls.Add(this.txtFName);
            this.panel2.Controls.Add(this.txtdate);
            this.panel2.Controls.Add(this.txtprovince);
            this.panel2.Controls.Add(this.txtpob);
            this.panel2.Controls.Add(this.txtcity);
            this.panel2.Controls.Add(this.txtAltPhone);
            this.panel2.Controls.Add(this.txtPhone);
            this.panel2.Controls.Add(this.txtemail);
            this.panel2.Controls.Add(this.txtId);
            this.panel2.Location = new System.Drawing.Point(56, 102);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(586, 459);
            this.panel2.TabIndex = 11;
            // 
            // cboCountry
            // 
            this.cboCountry.BackColor = System.Drawing.Color.Transparent;
            this.cboCountry.BorderRadius = 3;
            this.cboCountry.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cboCountry.DisabledColor = System.Drawing.Color.Gray;
            this.cboCountry.ForeColor = System.Drawing.Color.White;
            this.cboCountry.Items = new string[] {
        "Registrar",
        "Transaferer",
        "Finance"};
            this.cboCountry.Location = new System.Drawing.Point(32, 310);
            this.cboCountry.Name = "cboCountry";
            this.cboCountry.NomalColor = System.Drawing.Color.Transparent;
            this.cboCountry.onHoverColor = System.Drawing.Color.LightBlue;
            this.cboCountry.selectedIndex = -1;
            this.cboCountry.Size = new System.Drawing.Size(214, 28);
            this.cboCountry.TabIndex = 8;
            this.cboCountry.onItemSelected += new System.EventHandler(this.cboRole_onItemSelected);
            // 
            // cbotype
            // 
            this.cbotype.BackColor = System.Drawing.Color.Transparent;
            this.cbotype.BorderRadius = 3;
            this.cbotype.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cbotype.DisabledColor = System.Drawing.Color.Gray;
            this.cbotype.ForeColor = System.Drawing.Color.White;
            this.cbotype.Items = new string[] {
        "Admin",
        "User"};
            this.cbotype.Location = new System.Drawing.Point(164, 409);
            this.cbotype.Name = "cbotype";
            this.cbotype.NomalColor = System.Drawing.Color.Transparent;
            this.cbotype.onHoverColor = System.Drawing.Color.LightBlue;
            this.cbotype.selectedIndex = -1;
            this.cbotype.Size = new System.Drawing.Size(214, 28);
            this.cbotype.TabIndex = 9;
            this.cbotype.onItemSelected += new System.EventHandler(this.cboRole_onItemSelected);
            // 
            // cboRole
            // 
            this.cboRole.BackColor = System.Drawing.Color.Transparent;
            this.cboRole.BorderRadius = 3;
            this.cboRole.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cboRole.DisabledColor = System.Drawing.Color.Gray;
            this.cboRole.ForeColor = System.Drawing.Color.White;
            this.cboRole.Items = new string[] {
        "Registrar",
        "Transaferer",
        "Finance"};
            this.cboRole.Location = new System.Drawing.Point(265, 311);
            this.cboRole.Name = "cboRole";
            this.cboRole.NomalColor = System.Drawing.Color.Transparent;
            this.cboRole.onHoverColor = System.Drawing.Color.LightBlue;
            this.cboRole.selectedIndex = -1;
            this.cboRole.Size = new System.Drawing.Size(214, 28);
            this.cboRole.TabIndex = 9;
            this.cboRole.onItemSelected += new System.EventHandler(this.cboRole_onItemSelected);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(276, 289);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(99, 18);
            this.label11.TabIndex = 20;
            this.label11.Text = "Admin Role:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(38, 414);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(121, 18);
            this.label14.TabIndex = 21;
            this.label14.Text = "Email Address:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(44, 346);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(121, 18);
            this.label12.TabIndex = 21;
            this.label12.Text = "Email Address:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(44, 289);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(72, 18);
            this.label10.TabIndex = 19;
            this.label10.Text = "Country:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(276, 222);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 18);
            this.label9.TabIndex = 18;
            this.label9.Text = "Province:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(44, 222);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(42, 18);
            this.label8.TabIndex = 17;
            this.label8.Text = "City:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(276, 156);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(111, 18);
            this.label7.TabIndex = 16;
            this.label7.Text = "Date Of Birth:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(44, 156);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(118, 18);
            this.label6.TabIndex = 15;
            this.label6.Text = "Place Of Birth:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(276, 86);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(85, 18);
            this.label5.TabIndex = 14;
            this.label5.Text = "Alt.Phone:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(44, 86);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 18);
            this.label4.TabIndex = 13;
            this.label4.Text = "Phone:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(276, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 18);
            this.label3.TabIndex = 12;
            this.label3.Text = "Full Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(44, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 18);
            this.label2.TabIndex = 11;
            this.label2.Text = "Identification:";
            // 
            // datetimePicker
            // 
            this.datetimePicker.BackColor = System.Drawing.Color.SeaGreen;
            this.datetimePicker.BorderRadius = 0;
            this.datetimePicker.ForeColor = System.Drawing.Color.White;
            this.datetimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.datetimePicker.FormatCustom = null;
            this.datetimePicker.Location = new System.Drawing.Point(486, 181);
            this.datetimePicker.Name = "datetimePicker";
            this.datetimePicker.Size = new System.Drawing.Size(33, 28);
            this.datetimePicker.TabIndex = 22;
            this.datetimePicker.Value = new System.DateTime(2017, 10, 1, 7, 6, 39, 612);
            this.datetimePicker.onValueChanged += new System.EventHandler(this.bunifuDatepicker1_onValueChanged);
            // 
            // txtFName
            // 
            this.txtFName.BorderColorFocused = System.Drawing.Color.LightSteelBlue;
            this.txtFName.BorderColorIdle = System.Drawing.Color.DeepSkyBlue;
            this.txtFName.BorderColorMouseHover = System.Drawing.Color.LightSkyBlue;
            this.txtFName.BorderThickness = 3;
            this.txtFName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtFName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtFName.ForeColor = System.Drawing.Color.White;
            this.txtFName.isPassword = false;
            this.txtFName.Location = new System.Drawing.Point(265, 48);
            this.txtFName.Margin = new System.Windows.Forms.Padding(4);
            this.txtFName.Name = "txtFName";
            this.txtFName.Size = new System.Drawing.Size(315, 32);
            this.txtFName.TabIndex = 1;
            this.txtFName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtFName.Enter += new System.EventHandler(this.txtFName_Enter);
            // 
            // txtdate
            // 
            this.txtdate.BorderColorFocused = System.Drawing.Color.LightSteelBlue;
            this.txtdate.BorderColorIdle = System.Drawing.Color.DeepSkyBlue;
            this.txtdate.BorderColorMouseHover = System.Drawing.Color.LightSkyBlue;
            this.txtdate.BorderThickness = 3;
            this.txtdate.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtdate.Enabled = false;
            this.txtdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtdate.ForeColor = System.Drawing.Color.White;
            this.txtdate.isPassword = false;
            this.txtdate.Location = new System.Drawing.Point(265, 177);
            this.txtdate.Margin = new System.Windows.Forms.Padding(4);
            this.txtdate.Name = "txtdate";
            this.txtdate.Size = new System.Drawing.Size(214, 32);
            this.txtdate.TabIndex = 5;
            this.txtdate.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtprovince
            // 
            this.txtprovince.BorderColorFocused = System.Drawing.Color.LightSteelBlue;
            this.txtprovince.BorderColorIdle = System.Drawing.Color.DeepSkyBlue;
            this.txtprovince.BorderColorMouseHover = System.Drawing.Color.LightSkyBlue;
            this.txtprovince.BorderThickness = 3;
            this.txtprovince.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtprovince.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtprovince.ForeColor = System.Drawing.Color.White;
            this.txtprovince.isPassword = false;
            this.txtprovince.Location = new System.Drawing.Point(265, 244);
            this.txtprovince.Margin = new System.Windows.Forms.Padding(4);
            this.txtprovince.Name = "txtprovince";
            this.txtprovince.Size = new System.Drawing.Size(214, 32);
            this.txtprovince.TabIndex = 7;
            this.txtprovince.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtpob
            // 
            this.txtpob.BorderColorFocused = System.Drawing.Color.LightSteelBlue;
            this.txtpob.BorderColorIdle = System.Drawing.Color.DeepSkyBlue;
            this.txtpob.BorderColorMouseHover = System.Drawing.Color.LightSkyBlue;
            this.txtpob.BorderThickness = 3;
            this.txtpob.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtpob.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtpob.ForeColor = System.Drawing.Color.White;
            this.txtpob.isPassword = false;
            this.txtpob.Location = new System.Drawing.Point(32, 177);
            this.txtpob.Margin = new System.Windows.Forms.Padding(4);
            this.txtpob.Name = "txtpob";
            this.txtpob.Size = new System.Drawing.Size(214, 32);
            this.txtpob.TabIndex = 4;
            this.txtpob.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtcity
            // 
            this.txtcity.BorderColorFocused = System.Drawing.Color.LightSteelBlue;
            this.txtcity.BorderColorIdle = System.Drawing.Color.DeepSkyBlue;
            this.txtcity.BorderColorMouseHover = System.Drawing.Color.LightSkyBlue;
            this.txtcity.BorderThickness = 3;
            this.txtcity.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtcity.ForeColor = System.Drawing.Color.White;
            this.txtcity.isPassword = false;
            this.txtcity.Location = new System.Drawing.Point(32, 244);
            this.txtcity.Margin = new System.Windows.Forms.Padding(4);
            this.txtcity.Name = "txtcity";
            this.txtcity.Size = new System.Drawing.Size(214, 32);
            this.txtcity.TabIndex = 6;
            this.txtcity.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtAltPhone
            // 
            this.txtAltPhone.BorderColorFocused = System.Drawing.Color.LightSteelBlue;
            this.txtAltPhone.BorderColorIdle = System.Drawing.Color.DeepSkyBlue;
            this.txtAltPhone.BorderColorMouseHover = System.Drawing.Color.LightSkyBlue;
            this.txtAltPhone.BorderThickness = 3;
            this.txtAltPhone.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtAltPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtAltPhone.ForeColor = System.Drawing.Color.White;
            this.txtAltPhone.isPassword = false;
            this.txtAltPhone.Location = new System.Drawing.Point(265, 108);
            this.txtAltPhone.Margin = new System.Windows.Forms.Padding(4);
            this.txtAltPhone.Name = "txtAltPhone";
            this.txtAltPhone.Size = new System.Drawing.Size(214, 32);
            this.txtAltPhone.TabIndex = 3;
            this.txtAltPhone.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtPhone
            // 
            this.txtPhone.BorderColorFocused = System.Drawing.Color.LightSteelBlue;
            this.txtPhone.BorderColorIdle = System.Drawing.Color.DeepSkyBlue;
            this.txtPhone.BorderColorMouseHover = System.Drawing.Color.LightSkyBlue;
            this.txtPhone.BorderThickness = 3;
            this.txtPhone.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtPhone.ForeColor = System.Drawing.Color.White;
            this.txtPhone.isPassword = false;
            this.txtPhone.Location = new System.Drawing.Point(32, 108);
            this.txtPhone.Margin = new System.Windows.Forms.Padding(4);
            this.txtPhone.Name = "txtPhone";
            this.txtPhone.Size = new System.Drawing.Size(214, 32);
            this.txtPhone.TabIndex = 2;
            this.txtPhone.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtemail
            // 
            this.txtemail.BorderColorFocused = System.Drawing.Color.LightSteelBlue;
            this.txtemail.BorderColorIdle = System.Drawing.Color.DeepSkyBlue;
            this.txtemail.BorderColorMouseHover = System.Drawing.Color.LightSkyBlue;
            this.txtemail.BorderThickness = 3;
            this.txtemail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtemail.ForeColor = System.Drawing.Color.White;
            this.txtemail.isPassword = false;
            this.txtemail.Location = new System.Drawing.Point(32, 368);
            this.txtemail.Margin = new System.Windows.Forms.Padding(4);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(447, 32);
            this.txtemail.TabIndex = 10;
            this.txtemail.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtId
            // 
            this.txtId.BorderColorFocused = System.Drawing.Color.LightSteelBlue;
            this.txtId.BorderColorIdle = System.Drawing.Color.DeepSkyBlue;
            this.txtId.BorderColorMouseHover = System.Drawing.Color.LightSkyBlue;
            this.txtId.BorderThickness = 3;
            this.txtId.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtId.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtId.ForeColor = System.Drawing.Color.White;
            this.txtId.isPassword = false;
            this.txtId.Location = new System.Drawing.Point(32, 48);
            this.txtId.Margin = new System.Windows.Forms.Padding(4);
            this.txtId.Name = "txtId";
            this.txtId.Size = new System.Drawing.Size(214, 32);
            this.txtId.TabIndex = 0;
            this.txtId.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtId.Leave += new System.EventHandler(this.txtId_Leave);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.btnupdate);
            this.panel4.Controls.Add(this.btnSave);
            this.panel4.Controls.Add(this.btnNew);
            this.panel4.Location = new System.Drawing.Point(56, 561);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(586, 85);
            this.panel4.TabIndex = 1;
            // 
            // btnSave
            // 
            this.btnSave.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnSave.BackColor = System.Drawing.Color.Gray;
            this.btnSave.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSave.BorderRadius = 0;
            this.btnSave.ButtonText = "  Save";
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.DisabledColor = System.Drawing.Color.Gray;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Iconcolor = System.Drawing.Color.Transparent;
            this.btnSave.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnSave.Iconimage")));
            this.btnSave.Iconimage_right = null;
            this.btnSave.Iconimage_right_Selected = null;
            this.btnSave.Iconimage_Selected = null;
            this.btnSave.IconMarginLeft = 0;
            this.btnSave.IconMarginRight = 0;
            this.btnSave.IconRightVisible = true;
            this.btnSave.IconRightZoom = 0D;
            this.btnSave.IconVisible = true;
            this.btnSave.IconZoom = 60D;
            this.btnSave.IsTab = false;
            this.btnSave.Location = new System.Drawing.Point(468, 22);
            this.btnSave.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSave.Name = "btnSave";
            this.btnSave.Normalcolor = System.Drawing.Color.Gray;
            this.btnSave.OnHovercolor = System.Drawing.Color.Silver;
            this.btnSave.OnHoverTextColor = System.Drawing.Color.White;
            this.btnSave.selected = false;
            this.btnSave.Size = new System.Drawing.Size(107, 43);
            this.btnSave.TabIndex = 0;
            this.btnSave.Text = "  Save";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.Textcolor = System.Drawing.Color.White;
            this.btnSave.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnNew
            // 
            this.btnNew.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnNew.BackColor = System.Drawing.Color.Gray;
            this.btnNew.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnNew.BorderRadius = 0;
            this.btnNew.ButtonText = "  New";
            this.btnNew.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnNew.DisabledColor = System.Drawing.Color.Gray;
            this.btnNew.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.Iconcolor = System.Drawing.Color.Transparent;
            this.btnNew.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnNew.Iconimage")));
            this.btnNew.Iconimage_right = null;
            this.btnNew.Iconimage_right_Selected = null;
            this.btnNew.Iconimage_Selected = null;
            this.btnNew.IconMarginLeft = 0;
            this.btnNew.IconMarginRight = 0;
            this.btnNew.IconRightVisible = true;
            this.btnNew.IconRightZoom = 0D;
            this.btnNew.IconVisible = true;
            this.btnNew.IconZoom = 60D;
            this.btnNew.IsTab = false;
            this.btnNew.Location = new System.Drawing.Point(347, 22);
            this.btnNew.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnNew.Name = "btnNew";
            this.btnNew.Normalcolor = System.Drawing.Color.Gray;
            this.btnNew.OnHovercolor = System.Drawing.Color.Silver;
            this.btnNew.OnHoverTextColor = System.Drawing.Color.White;
            this.btnNew.selected = false;
            this.btnNew.Size = new System.Drawing.Size(107, 43);
            this.btnNew.TabIndex = 0;
            this.btnNew.Text = "  New";
            this.btnNew.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnNew.Textcolor = System.Drawing.Color.White;
            this.btnNew.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNew.Click += new System.EventHandler(this.bunifuFlatButton1_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(698, 28);
            this.panel1.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(675, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(24, 26);
            this.label1.TabIndex = 1;
            this.label1.Text = "X";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(12, -3);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(99, 99);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 15;
            this.pictureBox3.TabStop = false;
            // 
            // label13
            // 
            this.label13.Font = new System.Drawing.Font("Palatino Linotype", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.label13.Location = new System.Drawing.Point(132, 9);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(510, 87);
            this.label13.TabIndex = 9;
            this.label13.Text = resources.GetString("label13.Text");
            // 
            // btnupdate
            // 
            this.btnupdate.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnupdate.BackColor = System.Drawing.Color.Gray;
            this.btnupdate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnupdate.BorderRadius = 0;
            this.btnupdate.ButtonText = "  Update";
            this.btnupdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnupdate.DisabledColor = System.Drawing.Color.Gray;
            this.btnupdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdate.Iconcolor = System.Drawing.Color.Transparent;
            this.btnupdate.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnupdate.Iconimage")));
            this.btnupdate.Iconimage_right = null;
            this.btnupdate.Iconimage_right_Selected = null;
            this.btnupdate.Iconimage_Selected = null;
            this.btnupdate.IconMarginLeft = 0;
            this.btnupdate.IconMarginRight = 0;
            this.btnupdate.IconRightVisible = true;
            this.btnupdate.IconRightZoom = 0D;
            this.btnupdate.IconVisible = true;
            this.btnupdate.IconZoom = 60D;
            this.btnupdate.IsTab = false;
            this.btnupdate.Location = new System.Drawing.Point(468, 22);
            this.btnupdate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Normalcolor = System.Drawing.Color.Gray;
            this.btnupdate.OnHovercolor = System.Drawing.Color.Silver;
            this.btnupdate.OnHoverTextColor = System.Drawing.Color.White;
            this.btnupdate.selected = false;
            this.btnupdate.Size = new System.Drawing.Size(107, 43);
            this.btnupdate.TabIndex = 0;
            this.btnupdate.Text = "  Update";
            this.btnupdate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnupdate.Textcolor = System.Drawing.Color.White;
            this.btnupdate.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdate.Click += new System.EventHandler(this.btnupdate_Click);
            // 
            // frmAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(30)))));
            this.ClientSize = new System.Drawing.Size(699, 689);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.Name = "frmAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "1";
            this.Load += new System.EventHandler(this.frmAdmin_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        public Bunifu.Framework.UI.BunifuMetroTextbox txtId;
        private Bunifu.Framework.UI.BunifuDatepicker datetimePicker;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtFName;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtpob;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtAltPhone;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtPhone;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtdate;
        public Bunifu.Framework.UI.BunifuDropdown cboRole;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtprovince;
        private Bunifu.Framework.UI.BunifuMetroTextbox txtcity;
        public Bunifu.Framework.UI.BunifuMetroTextbox txtemail;
        private System.Windows.Forms.Panel panel4;
        public Bunifu.Framework.UI.BunifuFlatButton btnSave;
        public Bunifu.Framework.UI.BunifuFlatButton btnNew;
        public System.Windows.Forms.Label label11;
        public System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label13;
        private Bunifu.Framework.UI.BunifuDropdown cboCountry;
        public Bunifu.Framework.UI.BunifuDropdown cbotype;
        public System.Windows.Forms.Label label14;
        public Bunifu.Framework.UI.BunifuFlatButton btnupdate;
    }
}