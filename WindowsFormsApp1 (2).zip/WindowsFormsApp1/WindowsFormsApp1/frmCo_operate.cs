﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1;
using MySql.Data.MySqlClient;
using System.IO;

namespace WindowsFormsApp1
{
    public partial class frmCo_operate : Form
    {
        clsConnection obj = new clsConnection();
        public frmCo_operate()
        {
            InitializeComponent();
        }
        private void label1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (txtcode.Text == "")
            {
                MessageBox.Show("Enter Company Code!");
                txtcode.Focus();
                return;
            }
            if (txtcompName.Text == "Company Name" || txtcompName.Text =="")
            {
                MessageBox.Show("Enter Company Name");
                txtcompName.Focus();
                return;
            }
            if (cboRole.selectedIndex == -1)
            {
                MessageBox.Show("Select do-operate mode!");
                cboRole.Focus();
                return;
            }

            if (!is_request_exist(clsConnection.companyCode, txtcode.Text))
            {
                if (!is_record_exist(clsConnection.companyCode, txtcode.Text))
                {
                    add_record();
                    MessageBox.Show("Record Successfully Added!");
                }
                else
                {
                    MessageBox.Show("Duplicate request not accepting, contact to the admin!");
                }
            }
            else
            {
                if (request_status == "Requested")
                {
                    MessageBox.Show("This Company has already requested to your company and not yet been accepted");
                }
                else if (request_status == "Accepted")
                {
                    MessageBox.Show("This Company has already requested to your company and you have accepted");
                }
                else if (request_status == "Rejected")
                {
                    MessageBox.Show("This Company has already requested to your company and you have rejected");
                }  
            }
            clear_objects();
        }
        private void clear_objects()
        {
            txtcode.Text = "";
            txtcompName.Text = "Company Name";
            cboRole.selectedIndex = -1;

        }
       
        private void add_record()
        {
            MySqlCommand cmd = new MySqlCommand();
            MySqlParameter prm = new MySqlParameter();
            String sql = "Insert into co_operations (first_code,first_company,second_code,Second_company,Cooperate_mode,Request_mode,Req_date,Confirm_mode)";
            sql += " values(@first_code,@first_company,@second_code,@Second_company,@Cooperate_mode,@Request_mode,@Req_date,@Confirm_mode)";
            obj.conn_open();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = obj.cnn;
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@first_code", clsConnection.companyCode);
            cmd.Parameters.AddWithValue("@first_company", clsConnection.companyName);
            cmd.Parameters.AddWithValue("@second_code", txtcode.Text);
            cmd.Parameters.AddWithValue("@Second_company", txtcompName.Text);
            cmd.Parameters.AddWithValue("@Cooperate_mode", cboRole.selectedValue);
            cmd.Parameters.AddWithValue("@Request_mode", "Requested");
            cmd.Parameters.AddWithValue("@Req_date", DateTime.Now);
            cmd.Parameters.AddWithValue("@Confirm_mode", "No");
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            obj.conn_close();
        }
        public static string request_status;
        public bool is_request_exist(String my_comp, string co_comp)
        {
            obj.conn_open();
            String sql = "Select * from co_operations where second_code='" + my_comp + "' and first_code ='" + co_comp + "'";
            MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
            MySqlDataReader dr;
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                request_status = dr[7].ToString();
                dr.Dispose();
                obj.conn_close();
                return true;
            }
            else
            {
                dr.Dispose();
                obj.conn_close();
                return false;
            }
        }
        private bool is_record_exist(String my_comp, string co_comp)
        {
            obj.conn_open();
            String sql = "Select * from co_operations where second_code='" + co_comp + "' and first_code ='" + my_comp + "'";
            MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
            MySqlDataReader dr;
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                dr.Dispose();
                obj.conn_close();
                return true;
            }
            else
            {
                dr.Dispose();
                obj.conn_close();
                return false;
            }
        }
        private void txtcode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                if (txtcode.Text == "" || txtcode.Text.Length == 0)
                {
                    MessageBox.Show("Enter company Code");
                    txtcode.Focus();
                    return;
                }
                String sql = "select * from companies where code = '" + (txtcode.Text) + "' and code !='" + clsConnection.companyCode + "'";
                obj.conn_open();
                MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
                MySqlDataReader dr;
                String cname = string.Empty ;
                byte[] clogo = null;
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    cname = (dr[1].ToString());
                    clogo = (byte[])dr[11];
                }
                dr.Dispose();
                obj.conn_close();
                if (cname !="" && clogo != null)
                {
                    txtcompName.Text = cname;
                    MemoryStream ms = new MemoryStream(clogo);
                    pblogo.Image = Image.FromStream(ms);
                }
            }
        }
        private void txtcode_OnValueChanged(object sender, EventArgs e)
        {
            //if (txtcode.Text == "")
            //{
            //    txtcompName.Text = "";
            //    pblogo.Image = null;
            //}
        }

       

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            txtcompName.AutoCompleteMode = AutoCompleteMode.Suggest;
            txtcompName.AutoCompleteSource = AutoCompleteSource.CustomSource;
            AutoCompleteStringCollection DataCollection = new AutoCompleteStringCollection();
            GetData_from(DataCollection);
            txtcompName.AutoCompleteCustomSource = DataCollection;
            fill_by_company();
        }

        private void GetData_from(AutoCompleteStringCollection dataCollection)
        {
            string sql = "SELECT  company_name FROM companies where company_name like '%" + txtcompName.Text + "%'  and code !='" + clsConnection.companyCode + "'"; 
            //try
            //{
                obj.conn_open();
                MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
                MySqlDataAdapter ad = new MySqlDataAdapter();
                DataSet ds = new DataSet();
                ad.SelectCommand = cmd;
                ad.Fill(ds);
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    dataCollection.Add(row[0].ToString());
                }
                //ds.Dispose();
                ad.Dispose();
                cmd.Dispose();
                obj.conn_close();
            //}
            // catch (Exception ex)
            //{
            //MessageBox.Show("Can not open connection ! \n" + ex.ToString());
            //}
        }
    

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {

            }
        }

        private void fill_by_company()
        {
            String sql = "select * from companies where company_name = '" + txtcompName.Text + "'";
            obj.conn_open();
            MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
            MySqlDataReader dr;
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                txtcode.Text = (dr[0].ToString());
                MemoryStream ms = new MemoryStream((byte[])dr[11]);
                pblogo.Image = Image.FromStream(ms);
            }
            dr.Dispose();
            obj.conn_close();
        }

        private void txtcompName_Enter(object sender, EventArgs e)
        {
            if (txtcompName.Text == "Company Name")
            {
                txtcompName.Text = "";
            }
        }
    }
}
