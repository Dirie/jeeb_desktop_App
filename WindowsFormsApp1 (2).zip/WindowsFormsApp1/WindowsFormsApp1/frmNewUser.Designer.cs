﻿namespace WindowsFormsApp1
{
    partial class frmNewUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmNewUser));
            this.btncreate = new Bunifu.Framework.UI.BunifuThinButton2();
            this.txtusreName = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtemail = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label1 = new System.Windows.Forms.Label();
            this.cboRole = new Bunifu.Framework.UI.BunifuDropdown();
            this.label2 = new System.Windows.Forms.Label();
            this.pbComLogo = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbComLogo)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btncreate
            // 
            this.btncreate.ActiveBorderThickness = 1;
            this.btncreate.ActiveCornerRadius = 20;
            this.btncreate.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btncreate.ActiveForecolor = System.Drawing.Color.White;
            this.btncreate.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btncreate.BackColor = System.Drawing.Color.White;
            this.btncreate.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btncreate.BackgroundImage")));
            this.btncreate.ButtonText = "Create";
            this.btncreate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btncreate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncreate.ForeColor = System.Drawing.Color.SeaGreen;
            this.btncreate.IdleBorderThickness = 1;
            this.btncreate.IdleCornerRadius = 20;
            this.btncreate.IdleFillColor = System.Drawing.Color.White;
            this.btncreate.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btncreate.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btncreate.Location = new System.Drawing.Point(138, 350);
            this.btncreate.Margin = new System.Windows.Forms.Padding(5);
            this.btncreate.Name = "btncreate";
            this.btncreate.Size = new System.Drawing.Size(125, 41);
            this.btncreate.TabIndex = 1;
            this.btncreate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btncreate.Click += new System.EventHandler(this.btncreate_Click);
            // 
            // txtusreName
            // 
            this.txtusreName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtusreName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtusreName.ForeColor = System.Drawing.Color.Black;
            this.txtusreName.HintForeColor = System.Drawing.Color.Empty;
            this.txtusreName.HintText = "User Name";
            this.txtusreName.isPassword = false;
            this.txtusreName.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtusreName.LineIdleColor = System.Drawing.Color.SaddleBrown;
            this.txtusreName.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtusreName.LineThickness = 3;
            this.txtusreName.Location = new System.Drawing.Point(13, 138);
            this.txtusreName.Margin = new System.Windows.Forms.Padding(4);
            this.txtusreName.Name = "txtusreName";
            this.txtusreName.Size = new System.Drawing.Size(250, 30);
            this.txtusreName.TabIndex = 8;
            this.txtusreName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtemail
            // 
            this.txtemail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtemail.ForeColor = System.Drawing.Color.Black;
            this.txtemail.HintForeColor = System.Drawing.Color.Empty;
            this.txtemail.HintText = "Email Address";
            this.txtemail.isPassword = false;
            this.txtemail.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtemail.LineIdleColor = System.Drawing.Color.SaddleBrown;
            this.txtemail.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtemail.LineThickness = 3;
            this.txtemail.Location = new System.Drawing.Point(13, 100);
            this.txtemail.Margin = new System.Windows.Forms.Padding(4);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(250, 30);
            this.txtemail.TabIndex = 9;
            this.txtemail.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(17, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 20);
            this.label1.TabIndex = 10;
            this.label1.Text = "Create New User";
            // 
            // cboRole
            // 
            this.cboRole.BackColor = System.Drawing.Color.Transparent;
            this.cboRole.BorderRadius = 3;
            this.cboRole.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cboRole.DisabledColor = System.Drawing.Color.Gray;
            this.cboRole.ForeColor = System.Drawing.Color.Black;
            this.cboRole.Items = new string[] {
        "Admin",
        "User"};
            this.cboRole.Location = new System.Drawing.Point(13, 204);
            this.cboRole.Name = "cboRole";
            this.cboRole.NomalColor = System.Drawing.Color.Transparent;
            this.cboRole.onHoverColor = System.Drawing.Color.LightBlue;
            this.cboRole.selectedIndex = -1;
            this.cboRole.Size = new System.Drawing.Size(250, 28);
            this.cboRole.TabIndex = 11;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 186);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 13);
            this.label2.TabIndex = 12;
            this.label2.Text = "User Role";
            // 
            // pbComLogo
            // 
            this.pbComLogo.BackColor = System.Drawing.Color.Transparent;
            this.pbComLogo.Image = ((System.Drawing.Image)(resources.GetObject("pbComLogo.Image")));
            this.pbComLogo.Location = new System.Drawing.Point(12, 247);
            this.pbComLogo.Name = "pbComLogo";
            this.pbComLogo.Size = new System.Drawing.Size(97, 93);
            this.pbComLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbComLogo.TabIndex = 13;
            this.pbComLogo.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label3);
            this.panel1.Location = new System.Drawing.Point(-1, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(278, 25);
            this.panel1.TabIndex = 14;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(253, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(21, 20);
            this.label3.TabIndex = 10;
            this.label3.Text = "X";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // frmNewUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(275, 400);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pbComLogo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cboRole);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtusreName);
            this.Controls.Add(this.txtemail);
            this.Controls.Add(this.btncreate);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmNewUser";
            this.Text = "frmEditCompany";
            this.Load += new System.EventHandler(this.frmNewUser_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbComLogo)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private Bunifu.Framework.UI.BunifuThinButton2 btncreate;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtusreName;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtemail;
        private System.Windows.Forms.Label label1;
        public Bunifu.Framework.UI.BunifuDropdown cboRole;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pbComLogo;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label3;
    }
}