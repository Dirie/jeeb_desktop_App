﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Imaging;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{
    public partial class MDIAdmin : Form
    {
        clsConnection obj = new clsConnection();
        private static string val;
        public MDIAdmin()
        {
            InitializeComponent();
        }

        private void bunifuFlatButton7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void linkLabel5_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmCompanyList frm = new frmCompanyList();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.ShowDialog();
        }

        private void bunifuFlatButton7_Click_1(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("www.jeeb.com");
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            frmAdmin frm = new frmAdmin();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.btnNew.Visible = true;
            frm.btnupdate.Visible = false;

            frm.ShowDialog();
        }

        private void btnCompany_Click(object sender, EventArgs e)
        {
            frmCompany frm = new frmCompany();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.ShowDialog();

        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmAdmin frm = new frmAdmin();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.btnNew.Visible = false;
            frm.label14.Visible = false;
            frm.cbotype.Visible = false;
            frm.cboRole.Visible = false;
            frm.txtemail.Visible = false;
            frm.label12.Visible = false;
            frm.label11.Visible = false;
            frm.btnupdate.Visible = true;
            frm.btnSave.Visible = false;
            frm.txtId.Enabled = false;
            frm.txtId.Text = clsConnection.Adminid;
            frm.ShowDialog();
        }

        private void linkLabel20_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmChangeAdmin frm = new frmChangeAdmin();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.ShowDialog();
        }

        private void linkLabel8_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmCompany frm = new frmCompany();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmlogin frm = new frmlogin();
            this.Close();
            frm.Show();
        }

        private void MDIAdmin_Load(object sender, EventArgs e)
        {
            this.Left = this.Top = 0;
            this.Width = Screen.PrimaryScreen.WorkingArea.Width;
            this.Height = Screen.PrimaryScreen.WorkingArea.Height;

            MemoryStream ms = new MemoryStream(clsConnection.admin_photo);
            pictureBox1.Image = Image.FromStream(ms);
            pictureBox2.Image = Image.FromStream(ms);
            lblname.Text = clsConnection.AdminFullname;
            
            
            count_users("companyrequests");
            linkLabel9.Text = val;

            read_Partinership_requests( );
            lblConfirmPending.Text = request_mode;
        }

        private static string request_mode;
        private void read_Partinership_requests()
        {
            obj.conn_open();
            String sql = "Select count(*) from co_operations where  Request_mode='Accepted' and Confirm_mode='No'";
            MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
            MySqlDataReader dr;
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                request_mode = dr[0].ToString();
            }
            dr.Dispose();
            obj.conn_close();
        }

        private void MDIAdmin_Activated(object sender, EventArgs e)
        {
            MemoryStream ms = new MemoryStream(clsConnection.admin_photo);
            pictureBox1.Image = Image.FromStream(ms);
            count_users("admin_table");
            linkLabel1.Text = val;

            read_Partinership_requests();
            lblConfirmPending.Text = request_mode;
        }

        private void  count_users(string tbl)
        {
            obj.conn_open();
            String sql = "Select count(*) from " + tbl  +"";
            MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
            MySqlDataReader dr;
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
               
               val = (dr[0].ToString());             
            }
            dr.Dispose();
            obj.conn_close();
        }

        private void linkLabel5_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel5_LinkClicked_1(object sender, LinkLabelLinkClickedEventArgs e)
        {
            openFileDialog1.Filter = "jpeg|*.jpg|bmp|*.bmp|all files|*.*";
            DialogResult res = openFileDialog1.ShowDialog();
            if (res == DialogResult.OK)
            {
                pictureBox2.Image = Image.FromFile(openFileDialog1.FileName);
                update_admin_photo();
                pictureBox1.Image = Image.FromFile(openFileDialog1.FileName);
            }


        }

        private void update_admin_photo()
        {
            MemoryStream ms = new MemoryStream();
            pictureBox2.Image.Save(ms, ImageFormat.Jpeg);
            byte[] photo_aray = new byte[ms.Length];
            ms.Position = 0;
            ms.Read(photo_aray, 0, photo_aray.Length);

            MySqlCommand cmd = new MySqlCommand();
            MySqlParameter prm = new MySqlParameter();
            String sql = "update admin_table set photo=@photo where email=@email";

            obj.conn_open();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = obj.cnn;
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@email",clsConnection.AdminEmail);
            cmd.Parameters.AddWithValue("@photo", photo_aray);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            obj.conn_close();
            clsConnection.admin_photo = photo_aray;
        }

        private void linkLabel9_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmrequestList frm = new frmrequestList();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.ShowDialog();
        }

        private void linkLabel21_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmCodes frm = new frmCodes();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.ShowDialog();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void lblConfirmPending_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmConfrimRequest frm = new frmConfrimRequest();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.ShowDialog();
        }
    }
}
