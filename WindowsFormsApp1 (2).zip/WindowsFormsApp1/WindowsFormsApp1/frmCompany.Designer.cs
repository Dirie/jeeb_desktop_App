﻿namespace WindowsFormsApp1
{
    partial class frmCompany
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmCompany));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.chk_isActive = new System.Windows.Forms.CheckBox();
            this.btnSave = new Bunifu.Framework.UI.BunifuThinButton2();
            this.txtcompanyName = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtfName = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtphone = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtcode = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtemail = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.txtcity = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtpassword = new System.Windows.Forms.TextBox();
            this.cboCountry = new System.Windows.Forms.ComboBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnGenreate = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.cboProvince = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtaltPhone = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(0, 560);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(749, 128);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(33, -2);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(107, 101);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 0;
            this.pictureBox6.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Transparent;
            this.panel3.Controls.Add(this.label1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(749, 30);
            this.panel3.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Candara", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(725, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(24, 26);
            this.label1.TabIndex = 1;
            this.label1.Text = "X";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // chk_isActive
            // 
            this.chk_isActive.AutoSize = true;
            this.chk_isActive.Location = new System.Drawing.Point(20, 340);
            this.chk_isActive.Name = "chk_isActive";
            this.chk_isActive.Size = new System.Drawing.Size(67, 17);
            this.chk_isActive.TabIndex = 2;
            this.chk_isActive.Text = "Is Active";
            this.chk_isActive.UseVisualStyleBackColor = true;
            // 
            // btnSave
            // 
            this.btnSave.ActiveBorderThickness = 1;
            this.btnSave.ActiveCornerRadius = 20;
            this.btnSave.ActiveFillColor = System.Drawing.Color.SeaGreen;
            this.btnSave.ActiveForecolor = System.Drawing.Color.White;
            this.btnSave.ActiveLineColor = System.Drawing.Color.SeaGreen;
            this.btnSave.BackColor = System.Drawing.Color.White;
            this.btnSave.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSave.BackgroundImage")));
            this.btnSave.ButtonText = "Save";
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.SeaGreen;
            this.btnSave.IdleBorderThickness = 1;
            this.btnSave.IdleCornerRadius = 20;
            this.btnSave.IdleFillColor = System.Drawing.Color.White;
            this.btnSave.IdleForecolor = System.Drawing.Color.SeaGreen;
            this.btnSave.IdleLineColor = System.Drawing.Color.SeaGreen;
            this.btnSave.Location = new System.Drawing.Point(190, 350);
            this.btnSave.Margin = new System.Windows.Forms.Padding(5);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(119, 41);
            this.btnSave.TabIndex = 8;
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnSave.Click += new System.EventHandler(this.bunifuThinButton21_Click);
            // 
            // txtcompanyName
            // 
            this.txtcompanyName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtcompanyName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtcompanyName.ForeColor = System.Drawing.Color.Black;
            this.txtcompanyName.HintForeColor = System.Drawing.Color.Empty;
            this.txtcompanyName.HintText = "Company Name";
            this.txtcompanyName.isPassword = false;
            this.txtcompanyName.LineFocusedColor = System.Drawing.Color.CornflowerBlue;
            this.txtcompanyName.LineIdleColor = System.Drawing.Color.DarkBlue;
            this.txtcompanyName.LineMouseHoverColor = System.Drawing.Color.DodgerBlue;
            this.txtcompanyName.LineThickness = 3;
            this.txtcompanyName.Location = new System.Drawing.Point(20, 44);
            this.txtcompanyName.Margin = new System.Windows.Forms.Padding(4);
            this.txtcompanyName.Name = "txtcompanyName";
            this.txtcompanyName.Size = new System.Drawing.Size(288, 27);
            this.txtcompanyName.TabIndex = 0;
            this.txtcompanyName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtfName
            // 
            this.txtfName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtfName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtfName.ForeColor = System.Drawing.Color.Black;
            this.txtfName.HintForeColor = System.Drawing.Color.Empty;
            this.txtfName.HintText = "Full Name";
            this.txtfName.isPassword = false;
            this.txtfName.LineFocusedColor = System.Drawing.Color.CornflowerBlue;
            this.txtfName.LineIdleColor = System.Drawing.Color.DarkBlue;
            this.txtfName.LineMouseHoverColor = System.Drawing.Color.DodgerBlue;
            this.txtfName.LineThickness = 3;
            this.txtfName.Location = new System.Drawing.Point(20, 79);
            this.txtfName.Margin = new System.Windows.Forms.Padding(4);
            this.txtfName.Name = "txtfName";
            this.txtfName.Size = new System.Drawing.Size(288, 27);
            this.txtfName.TabIndex = 0;
            this.txtfName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtphone
            // 
            this.txtphone.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtphone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtphone.ForeColor = System.Drawing.Color.Black;
            this.txtphone.HintForeColor = System.Drawing.Color.Empty;
            this.txtphone.HintText = "Phone";
            this.txtphone.isPassword = false;
            this.txtphone.LineFocusedColor = System.Drawing.Color.CornflowerBlue;
            this.txtphone.LineIdleColor = System.Drawing.Color.DarkBlue;
            this.txtphone.LineMouseHoverColor = System.Drawing.Color.DodgerBlue;
            this.txtphone.LineThickness = 3;
            this.txtphone.Location = new System.Drawing.Point(20, 114);
            this.txtphone.Margin = new System.Windows.Forms.Padding(4);
            this.txtphone.Name = "txtphone";
            this.txtphone.Size = new System.Drawing.Size(142, 27);
            this.txtphone.TabIndex = 0;
            this.txtphone.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtcode
            // 
            this.txtcode.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtcode.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtcode.ForeColor = System.Drawing.Color.Black;
            this.txtcode.HintForeColor = System.Drawing.Color.Empty;
            this.txtcode.HintText = "Code";
            this.txtcode.isPassword = false;
            this.txtcode.LineFocusedColor = System.Drawing.Color.CornflowerBlue;
            this.txtcode.LineIdleColor = System.Drawing.Color.DarkBlue;
            this.txtcode.LineMouseHoverColor = System.Drawing.Color.DodgerBlue;
            this.txtcode.LineThickness = 3;
            this.txtcode.Location = new System.Drawing.Point(20, 12);
            this.txtcode.Margin = new System.Windows.Forms.Padding(4);
            this.txtcode.Name = "txtcode";
            this.txtcode.Size = new System.Drawing.Size(145, 27);
            this.txtcode.TabIndex = 0;
            this.txtcode.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtcode.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcode_KeyPress);
            // 
            // txtemail
            // 
            this.txtemail.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtemail.ForeColor = System.Drawing.Color.Black;
            this.txtemail.HintForeColor = System.Drawing.Color.Empty;
            this.txtemail.HintText = "Email";
            this.txtemail.isPassword = false;
            this.txtemail.LineFocusedColor = System.Drawing.Color.CornflowerBlue;
            this.txtemail.LineIdleColor = System.Drawing.Color.DarkBlue;
            this.txtemail.LineMouseHoverColor = System.Drawing.Color.DodgerBlue;
            this.txtemail.LineThickness = 3;
            this.txtemail.Location = new System.Drawing.Point(20, 149);
            this.txtemail.Margin = new System.Windows.Forms.Padding(4);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(289, 27);
            this.txtemail.TabIndex = 0;
            this.txtemail.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // txtcity
            // 
            this.txtcity.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtcity.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtcity.ForeColor = System.Drawing.Color.Black;
            this.txtcity.HintForeColor = System.Drawing.Color.Empty;
            this.txtcity.HintText = "City";
            this.txtcity.isPassword = false;
            this.txtcity.LineFocusedColor = System.Drawing.Color.CornflowerBlue;
            this.txtcity.LineIdleColor = System.Drawing.Color.DarkBlue;
            this.txtcity.LineMouseHoverColor = System.Drawing.Color.DodgerBlue;
            this.txtcity.LineThickness = 3;
            this.txtcity.Location = new System.Drawing.Point(20, 215);
            this.txtcity.Margin = new System.Windows.Forms.Padding(4);
            this.txtcity.Name = "txtcity";
            this.txtcity.Size = new System.Drawing.Size(171, 27);
            this.txtcity.TabIndex = 0;
            this.txtcity.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtpassword);
            this.panel1.Controls.Add(this.cboCountry);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.btnGenreate);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.cboProvince);
            this.panel1.Controls.Add(this.chk_isActive);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.btnSave);
            this.panel1.Controls.Add(this.txtcompanyName);
            this.panel1.Controls.Add(this.txtcode);
            this.panel1.Controls.Add(this.txtfName);
            this.panel1.Controls.Add(this.txtaltPhone);
            this.panel1.Controls.Add(this.txtphone);
            this.panel1.Controls.Add(this.txtemail);
            this.panel1.Controls.Add(this.txtcity);
            this.panel1.Location = new System.Drawing.Point(214, 81);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(334, 426);
            this.panel1.TabIndex = 9;
            // 
            // txtpassword
            // 
            this.txtpassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txtpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtpassword.Location = new System.Drawing.Point(20, 185);
            this.txtpassword.Name = "txtpassword";
            this.txtpassword.PasswordChar = '*';
            this.txtpassword.Size = new System.Drawing.Size(169, 19);
            this.txtpassword.TabIndex = 10;
            this.txtpassword.UseSystemPasswordChar = true;
            this.txtpassword.Enter += new System.EventHandler(this.txtpassword_Enter);
            this.txtpassword.MouseLeave += new System.EventHandler(this.txtpassword_MouseLeave);
            this.txtpassword.MouseHover += new System.EventHandler(this.txtpassword_MouseHover);
            // 
            // cboCountry
            // 
            this.cboCountry.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboCountry.FormattingEnabled = true;
            this.cboCountry.Location = new System.Drawing.Point(20, 292);
            this.cboCountry.Name = "cboCountry";
            this.cboCountry.Size = new System.Drawing.Size(171, 21);
            this.cboCountry.TabIndex = 10;
            this.cboCountry.Enter += new System.EventHandler(this.cboCountry_Enter);
            this.cboCountry.MouseLeave += new System.EventHandler(this.cboCountry_MouseLeave);
            this.cboCountry.MouseHover += new System.EventHandler(this.cboCountry_MouseHover);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.DarkBlue;
            this.panel5.Location = new System.Drawing.Point(20, 205);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(169, 3);
            this.panel5.TabIndex = 14;
            // 
            // btnGenreate
            // 
            this.btnGenreate.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnGenreate.BackColor = System.Drawing.Color.Gray;
            this.btnGenreate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnGenreate.BorderRadius = 0;
            this.btnGenreate.ButtonText = "Generate Code";
            this.btnGenreate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGenreate.DisabledColor = System.Drawing.Color.Gray;
            this.btnGenreate.Iconcolor = System.Drawing.Color.Transparent;
            this.btnGenreate.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnGenreate.Iconimage")));
            this.btnGenreate.Iconimage_right = null;
            this.btnGenreate.Iconimage_right_Selected = null;
            this.btnGenreate.Iconimage_Selected = null;
            this.btnGenreate.IconMarginLeft = 0;
            this.btnGenreate.IconMarginRight = 0;
            this.btnGenreate.IconRightVisible = true;
            this.btnGenreate.IconRightZoom = 0D;
            this.btnGenreate.IconVisible = true;
            this.btnGenreate.IconZoom = 50D;
            this.btnGenreate.IsTab = false;
            this.btnGenreate.Location = new System.Drawing.Point(177, 12);
            this.btnGenreate.Name = "btnGenreate";
            this.btnGenreate.Normalcolor = System.Drawing.Color.Gray;
            this.btnGenreate.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnGenreate.OnHoverTextColor = System.Drawing.Color.White;
            this.btnGenreate.selected = false;
            this.btnGenreate.Size = new System.Drawing.Size(141, 27);
            this.btnGenreate.TabIndex = 10;
            this.btnGenreate.Text = "Generate Code";
            this.btnGenreate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGenreate.Textcolor = System.Drawing.Color.White;
            this.btnGenreate.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGenreate.Click += new System.EventHandler(this.btnGenreate_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.DarkBlue;
            this.panel4.Location = new System.Drawing.Point(20, 314);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(169, 3);
            this.panel4.TabIndex = 14;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.DarkBlue;
            this.panel2.Location = new System.Drawing.Point(20, 279);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(169, 3);
            this.panel2.TabIndex = 14;
            // 
            // cboProvince
            // 
            this.cboProvince.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cboProvince.FormattingEnabled = true;
            this.cboProvince.Location = new System.Drawing.Point(20, 256);
            this.cboProvince.Name = "cboProvince";
            this.cboProvince.Size = new System.Drawing.Size(171, 21);
            this.cboProvince.TabIndex = 10;
            this.cboProvince.Enter += new System.EventHandler(this.cboProvince_Enter);
            this.cboProvince.MouseLeave += new System.EventHandler(this.cboProvince_MouseLeave);
            this.cboProvince.MouseHover += new System.EventHandler(this.cboProvince_MouseHover);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(193, 298);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(43, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "Country";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(194, 261);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(49, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Province";
            // 
            // txtaltPhone
            // 
            this.txtaltPhone.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtaltPhone.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.txtaltPhone.ForeColor = System.Drawing.Color.Black;
            this.txtaltPhone.HintForeColor = System.Drawing.Color.Empty;
            this.txtaltPhone.HintText = "Alternate Phone";
            this.txtaltPhone.isPassword = false;
            this.txtaltPhone.LineFocusedColor = System.Drawing.Color.CornflowerBlue;
            this.txtaltPhone.LineIdleColor = System.Drawing.Color.DarkBlue;
            this.txtaltPhone.LineMouseHoverColor = System.Drawing.Color.DodgerBlue;
            this.txtaltPhone.LineThickness = 3;
            this.txtaltPhone.Location = new System.Drawing.Point(169, 114);
            this.txtaltPhone.Margin = new System.Windows.Forms.Padding(4);
            this.txtaltPhone.Name = "txtaltPhone";
            this.txtaltPhone.Size = new System.Drawing.Size(140, 27);
            this.txtaltPhone.TabIndex = 0;
            this.txtaltPhone.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this;
            this.bunifuDragControl1.Vertical = true;
            // 
            // frmCompany
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(749, 688);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.Name = "frmCompany";
            this.Text = "frmCompany";
            this.Load += new System.EventHandler(this.frmCompany_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label1;
        public Bunifu.Framework.UI.BunifuThinButton2 btnSave;
        public Bunifu.Framework.UI.BunifuMaterialTextbox txtcompanyName;
        public Bunifu.Framework.UI.BunifuMaterialTextbox txtfName;
        public Bunifu.Framework.UI.BunifuMaterialTextbox txtphone;
        public Bunifu.Framework.UI.BunifuMaterialTextbox txtcode;
        public Bunifu.Framework.UI.BunifuMaterialTextbox txtemail;
        public Bunifu.Framework.UI.BunifuMaterialTextbox txtcity;
        private System.Windows.Forms.Panel panel1;
        public System.Windows.Forms.CheckBox chk_isActive;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel2;
        public System.Windows.Forms.ComboBox cboProvince;
        public System.Windows.Forms.ComboBox cboCountry;
        private System.Windows.Forms.Panel panel4;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        public System.Windows.Forms.TextBox txtpassword;
        private System.Windows.Forms.Panel panel5;
        private Bunifu.Framework.UI.BunifuFlatButton btnGenreate;
        public Bunifu.Framework.UI.BunifuMaterialTextbox txtaltPhone;
    }
}