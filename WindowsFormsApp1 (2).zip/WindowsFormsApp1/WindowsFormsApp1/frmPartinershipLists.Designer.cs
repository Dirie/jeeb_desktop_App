﻿namespace WindowsFormsApp1
{
    partial class frmPartinershipLists
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPartinershipLists));
            this.panel1 = new System.Windows.Forms.Panel();
            this.rbRejected = new System.Windows.Forms.RadioButton();
            this.rbRequested = new System.Windows.Forms.RadioButton();
            this.rbAccepted = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.txtsearch = new Bunifu.Framework.UI.BunifuTextbox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnChange = new Bunifu.Framework.UI.BunifuThinButton2();
            this.clsCode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmCompName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.clmRequests = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.clmDesc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.rbRejected);
            this.panel1.Controls.Add(this.rbRequested);
            this.panel1.Controls.Add(this.rbAccepted);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(56, -1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(803, 34);
            this.panel1.TabIndex = 0;
            // 
            // rbRejected
            // 
            this.rbRejected.AutoSize = true;
            this.rbRejected.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbRejected.ForeColor = System.Drawing.Color.Yellow;
            this.rbRejected.Location = new System.Drawing.Point(238, 8);
            this.rbRejected.Name = "rbRejected";
            this.rbRejected.Size = new System.Drawing.Size(89, 20);
            this.rbRejected.TabIndex = 2;
            this.rbRejected.TabStop = true;
            this.rbRejected.Text = "Rejected";
            this.rbRejected.UseVisualStyleBackColor = true;
            this.rbRejected.CheckedChanged += new System.EventHandler(this.rbRejected_CheckedChanged);
            // 
            // rbRequested
            // 
            this.rbRequested.AutoSize = true;
            this.rbRequested.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbRequested.ForeColor = System.Drawing.Color.Yellow;
            this.rbRequested.Location = new System.Drawing.Point(124, 8);
            this.rbRequested.Name = "rbRequested";
            this.rbRequested.Size = new System.Drawing.Size(102, 20);
            this.rbRequested.TabIndex = 2;
            this.rbRequested.TabStop = true;
            this.rbRequested.Text = "Requested";
            this.rbRequested.UseVisualStyleBackColor = true;
            this.rbRequested.CheckedChanged += new System.EventHandler(this.rbRequested_CheckedChanged);
            // 
            // rbAccepted
            // 
            this.rbAccepted.AutoSize = true;
            this.rbAccepted.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbAccepted.ForeColor = System.Drawing.Color.Yellow;
            this.rbAccepted.Location = new System.Drawing.Point(12, 8);
            this.rbAccepted.Name = "rbAccepted";
            this.rbAccepted.Size = new System.Drawing.Size(92, 20);
            this.rbAccepted.TabIndex = 2;
            this.rbAccepted.TabStop = true;
            this.rbAccepted.Text = "Accepted";
            this.rbAccepted.UseVisualStyleBackColor = true;
            this.rbAccepted.CheckedChanged += new System.EventHandler(this.rbAccepted_CheckedChanged);
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(775, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(25, 24);
            this.label1.TabIndex = 1;
            this.label1.Text = "X";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(12, -5);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 48);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 6;
            this.pictureBox2.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.clsCode,
            this.clmCompName,
            this.clmRequests,
            this.clmDesc});
            this.dataGridView1.Location = new System.Drawing.Point(3, 86);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(856, 512);
            this.dataGridView1.TabIndex = 7;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.Click += new System.EventHandler(this.dataGridView1_Click);
            // 
            // txtsearch
            // 
            this.txtsearch.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.txtsearch.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtsearch.BackgroundImage")));
            this.txtsearch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.txtsearch.ForeColor = System.Drawing.Color.White;
            this.txtsearch.Icon = ((System.Drawing.Image)(resources.GetObject("txtsearch.Icon")));
            this.txtsearch.Location = new System.Drawing.Point(131, 44);
            this.txtsearch.Name = "txtsearch";
            this.txtsearch.Size = new System.Drawing.Size(249, 29);
            this.txtsearch.TabIndex = 12;
            this.txtsearch.text = "";
            this.txtsearch.OnTextChange += new System.EventHandler(this.txtsearch_OnTextChange);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(66, 50);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 16);
            this.label2.TabIndex = 13;
            this.label2.Text = "Search:";
            // 
            // btnChange
            // 
            this.btnChange.ActiveBorderThickness = 1;
            this.btnChange.ActiveCornerRadius = 20;
            this.btnChange.ActiveFillColor = System.Drawing.Color.LightSkyBlue;
            this.btnChange.ActiveForecolor = System.Drawing.Color.White;
            this.btnChange.ActiveLineColor = System.Drawing.Color.Indigo;
            this.btnChange.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnChange.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnChange.BackgroundImage")));
            this.btnChange.ButtonText = "Change";
            this.btnChange.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnChange.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnChange.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.btnChange.IdleBorderThickness = 1;
            this.btnChange.IdleCornerRadius = 20;
            this.btnChange.IdleFillColor = System.Drawing.Color.White;
            this.btnChange.IdleForecolor = System.Drawing.Color.MidnightBlue;
            this.btnChange.IdleLineColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btnChange.Location = new System.Drawing.Point(752, 41);
            this.btnChange.Margin = new System.Windows.Forms.Padding(5);
            this.btnChange.Name = "btnChange";
            this.btnChange.Size = new System.Drawing.Size(82, 37);
            this.btnChange.TabIndex = 14;
            this.btnChange.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnChange.Click += new System.EventHandler(this.btnChange_Click);
            // 
            // clsCode
            // 
            this.clsCode.HeaderText = "Code";
            this.clsCode.Name = "clsCode";
            // 
            // clmCompName
            // 
            this.clmCompName.HeaderText = "Company Name";
            this.clmCompName.Name = "clmCompName";
            this.clmCompName.Width = 230;
            // 
            // clmRequests
            // 
            this.clmRequests.HeaderText = "Request Mode";
            this.clmRequests.Items.AddRange(new object[] {
            "Accepted",
            "Requested",
            "Rejected"});
            this.clmRequests.Name = "clmRequests";
            this.clmRequests.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.clmRequests.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.clmRequests.Width = 130;
            // 
            // clmDesc
            // 
            this.clmDesc.HeaderText = "Description";
            this.clmDesc.Name = "clmDesc";
            this.clmDesc.Width = 350;
            // 
            // frmPartinershipLists
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.ClientSize = new System.Drawing.Size(860, 599);
            this.Controls.Add(this.btnChange);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtsearch);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmPartinershipLists";
            this.Text = "frmPartinershipLists";
            this.Load += new System.EventHandler(this.frmPartinershipLists_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.PictureBox pictureBox2;
        public System.Windows.Forms.DataGridView dataGridView1;
        public Bunifu.Framework.UI.BunifuTextbox txtsearch;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.RadioButton rbRejected;
        public System.Windows.Forms.RadioButton rbRequested;
        public System.Windows.Forms.RadioButton rbAccepted;
        public Bunifu.Framework.UI.BunifuThinButton2 btnChange;
        private System.Windows.Forms.DataGridViewTextBoxColumn clsCode;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmCompName;
        private System.Windows.Forms.DataGridViewComboBoxColumn clmRequests;
        private System.Windows.Forms.DataGridViewTextBoxColumn clmDesc;
    }
}