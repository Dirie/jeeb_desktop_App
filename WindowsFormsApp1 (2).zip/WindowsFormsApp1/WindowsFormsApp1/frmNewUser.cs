﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;
using System.Drawing.Imaging;

namespace WindowsFormsApp1
{
    public partial class frmNewUser : Form
    {
        clsConnection obj = new clsConnection();
        public frmNewUser()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmNewUser_Load(object sender, EventArgs e)
        {
            MemoryStream ms = new MemoryStream(clsConnection.company_logo);
            pbComLogo.Image = Image.FromStream(ms);
        }

        private void btncreate_Click(object sender, EventArgs e)
        {
            if (txtusreName.Text == "")
            {
                MessageBox.Show("Enter user Name!");
                return;
            }
            if (cboRole.selectedIndex == -1)
            {
                MessageBox.Show("Select User role!");
                return;
            }
            System.Text.RegularExpressions.Regex rEMail = new System.Text.RegularExpressions.Regex(@"^[a-zA-Z][\w\.-]{2,28}[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$");
            if (txtemail.Text.Length > 0)
            {
                if (!rEMail.IsMatch(txtemail.Text))
                {
                    MessageBox.Show("E-Mail expected", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtemail.Text = "";
                    txtemail.Focus();
                    return;
                }
            }

            if (!is_record_exist(txtemail.Text))
            {

                add_user();
                MessageBox.Show("Record Successfully Added!");
            }
            else
            {
                    MessageBox.Show("This user has already exist!");
            }

        }
        private bool is_record_exist(String id)
        {
            obj.conn_open();
            String sql = "Select * from company_users where email='" + id + "'";
            MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
            MySqlDataReader dr;
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                dr.Dispose();
                obj.conn_close();
                return true;
            }
            else
            {
                dr.Dispose();
                obj.conn_close();
                return false;
            }
        }
        private void add_user()
        {
            MemoryStream ms = new MemoryStream();
            pbComLogo.Image.Save(ms, ImageFormat.Jpeg);
            byte[] photo_aray = new byte[ms.Length];
            ms.Position = 0;
            ms.Read(photo_aray, 0, photo_aray.Length);

            Random rnd = new Random();
            int n = rnd.Next();

            MySqlCommand cmd = new MySqlCommand();
            MySqlParameter prm = new MySqlParameter();
            String sql = "Insert into company_users (Email,pass,Hint,photo,Date,code,Role,userName)";
            sql += " values(@Email,@pass,@Hint,@photo,@Date,@code,@Role,@userName)";
            obj.conn_open();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = obj.cnn;
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@Email", txtemail.Text);
            cmd.Parameters.AddWithValue("@pass", n);
            cmd.Parameters.AddWithValue("@Hint", n.ToString().Substring(0, 3));
            cmd.Parameters.AddWithValue("@photo", photo_aray);
            cmd.Parameters.AddWithValue("@Date", DateTime.Now);
            cmd.Parameters.AddWithValue("@code", clsConnection.companyCode);
            cmd.Parameters.AddWithValue("@userName", txtusreName.Text);
            cmd.Parameters.AddWithValue("@Role", cboRole.selectedValue);

            cmd.ExecuteNonQuery();
            cmd.Dispose();
            obj.conn_close();
        }

        
    }
}
