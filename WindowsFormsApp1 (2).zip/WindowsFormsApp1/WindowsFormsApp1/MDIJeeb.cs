﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.IO;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{
    public partial class MDIJeeb : Form
    {
        clsConnection obj = new clsConnection();
        public MDIJeeb()
        {
            InitializeComponent();
        }

        private void MDIJeeb_Load(object sender, EventArgs e)
        {
            this.Left = this.Top = 0;
            this.Width = Screen.PrimaryScreen.WorkingArea.Width;
            this.Height = Screen.PrimaryScreen.WorkingArea.Height;

            System.Drawing.Drawing2D.GraphicsPath gp = new System.Drawing.Drawing2D.GraphicsPath();
            gp.AddEllipse(0, 0, pbuserPhoto1.Width - 3, pbuserPhoto1.Height - 3);
            Region rg = new Region(gp);
            pbuserPhoto1.Region = rg;

            MemoryStream ms = new MemoryStream(clsConnection.company_user_photo);
            pbuserPhoto1.Image = Image.FromStream(ms);
            pbuserPhoto2.Image = Image.FromStream(ms);

            lblUserName.Text = clsConnection.user_name;
            read_company_info(clsConnection.companyCode);

            lblcomCode.Text = clsConnection.companyCode;

            read_Partinership_requests(clsConnection.companyCode, "requested");
            lblRequests.Text = request_mode;
            read_Partinership_requests(clsConnection.companyCode, "accepted");
            lblAccepted.Text = request_mode;
            read_Partinership_requests(clsConnection.companyCode, "rejected");
            lblRejected.Text = request_mode;

            read_Partinership_sent_requests(clsConnection.companyCode, "requested");
            lblRequested.Text = request_mode;
            read_Partinership_sent_requests(clsConnection.companyCode, "accepted");
            lblaccept.Text = request_mode;
            read_Partinership_sent_requests(clsConnection.companyCode, "rejected");
            lblreject.Text = request_mode;

            lbldate.Text = DateTime.Now.ToShortDateString();
            lblTime.Text = DateTime.Now.ToShortTimeString();
        }

        private void  read_company_info(string code)
        {
            obj.conn_open();
            String sql = "Select * from companies where code='" + code.Replace("'", "''") + "'";
            MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
            MySqlDataReader dr;
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                lblcompName.Text = dr[1].ToString();
                clsConnection.companyName = dr[1].ToString();
                MemoryStream ms = new MemoryStream((byte[])dr[11]);
                pbComLogo.Image = Image.FromStream(ms);
                clsConnection.company_logo = (byte[])dr[11];
            }
            dr.Dispose();
           obj.conn_close();
        }

        private void bunifuFlatButton7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void bunifuFlatButton9_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.facebook.com/Jeeb-125263841531145/");
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            frmclients frm = new frmclients();
            // this.IsMdiContainer = true;
            //frm.MdiParent = this;
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.ShowDialog();
            
        }

        private void btnadmin_Click(object sender, EventArgs e)
        {
            frmAdmin frm = new frmAdmin();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.ShowDialog();
        }

        private void btncompany_Click(object sender, EventArgs e)
        {
            frmCompany frm = new frmCompany();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.ShowDialog();
        }

        private void bunifuFlatButton6_Click(object sender, EventArgs e)
        {
            frmNewUser frm = new frmNewUser();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.ShowDialog();
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton10_Click(object sender, EventArgs e)
        {
            frmlogin frm = new frmlogin();
            this.Close();
            frm.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmlogin frm = new frmlogin();
            this.Close();
            frm.Show();

        }

        private void bunifuFlatButton10_Click_1(object sender, EventArgs e)
        {

            frmCompany frm = new frmCompany();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.ShowDialog();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

       
        private void update_company_logo()
        {
            MemoryStream ms = new MemoryStream();
            pbComLogo.Image.Save(ms, ImageFormat.Jpeg);
            byte[] photo_aray = new byte[ms.Length];
            ms.Position = 0;
            ms.Read(photo_aray, 0, photo_aray.Length);

            MySqlCommand cmd = new MySqlCommand();
            MySqlParameter prm = new MySqlParameter();
            String sql = "update companies set Logo=@Logo where code=@code";

            obj.conn_open();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = obj.cnn;
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@code", clsConnection.companyCode);
            cmd.Parameters.AddWithValue("@Logo", photo_aray);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            obj.conn_close();
            clsConnection.company_logo = photo_aray;
        }

        private void pbComLogo_DoubleClick(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "jpeg|*.jpg|bmp|*.bmp|all files|*.*";
            DialogResult res = openFileDialog1.ShowDialog();
            if (res == DialogResult.OK)
            {
                pbComLogo.Image = Image.FromFile(openFileDialog1.FileName);
                update_company_logo();
            }
        }

        private void linkLabel5_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "jpeg|*.jpg|bmp|*.bmp|all files|*.*";
            DialogResult res = openFileDialog1.ShowDialog();
            if (res == DialogResult.OK)
            {
                pbuserPhoto2.Image = Image.FromFile(openFileDialog1.FileName);
                pbuserPhoto1.Image = Image.FromFile(openFileDialog1.FileName);
                update_company_User_photo();
            }
        }
        private void update_company_User_photo()
        {
            MemoryStream ms = new MemoryStream();
            pbuserPhoto2.Image.Save(ms, ImageFormat.Jpeg);
            byte[] photo_aray = new byte[ms.Length];
            ms.Position = 0;
            ms.Read(photo_aray, 0, photo_aray.Length);

            MySqlCommand cmd = new MySqlCommand();
            MySqlParameter prm = new MySqlParameter();
            String sql = "update company_users set photo=@photo where email=@email";

            obj.conn_open();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = obj.cnn;
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@email", clsConnection.comp_user_email);
            cmd.Parameters.AddWithValue("@photo", photo_aray);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            obj.conn_close();
            clsConnection.company_user_photo = photo_aray;
        }

        private void linkLabel4_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmUsers frm = new frmUsers();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.ShowDialog();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmClientList frm = new frmClientList();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.ShowDialog();
        }

        private void bunifuFlatButton4_Click(object sender, EventArgs e)
        {
            frmTransactions frm = new frmTransactions();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.ShowDialog();
        }

        private void bunifuFlatButton10_Click_2(object sender, EventArgs e)
        {
            frmCo_operate frm = new frmCo_operate();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.ShowDialog();
        }

        private void linkLabel15_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmCo_operate frm = new frmCo_operate();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.ShowDialog();
        }
        public static string request_mode;
        private void read_Partinership_requests(string code,string mode)
        {
            obj.conn_open();
            String sql = "Select count(*) from co_operations where second_code='" + code.Replace("'", "''") + "' and Request_mode='" + mode.Replace("'", "''") + "'" ;
            MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
            MySqlDataReader dr;
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                request_mode = dr[0].ToString();
            }
            dr.Dispose();
            obj.conn_close();
        }
        private void read_Partinership_sent_requests(string code, string mode)
        {
            obj.conn_open();
            String sql = "Select count(*) from co_operations where first_code='" + code.Replace("'", "''") + "' and Request_mode='" + mode.Replace("'", "''") + "'";
            MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
            MySqlDataReader dr;
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                request_mode = dr[0].ToString();
            }
            dr.Dispose();
            obj.conn_close();
        }

        private void lblRequests_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmPartinershipLists frm = new frmPartinershipLists();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.rbRequested.Checked = true;
            frm.fill_grid_type(frm.rbRequested.Text);
            frm.ShowDialog();
        }

        private void lblAccepted_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmPartinershipLists frm = new frmPartinershipLists();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.rbAccepted.Checked = true;
            frm.fill_grid_type(frm.rbAccepted.Text);
            frm.ShowDialog();
        }

        private void lblRejected_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmPartinershipLists frm = new frmPartinershipLists();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.rbRejected.Checked = true;
            frm.fill_grid_type(frm.rbRejected.Text);
            frm.ShowDialog();
        }

        private void MDIJeeb_Activated(object sender, EventArgs e)
        {
            System.Drawing.Drawing2D.GraphicsPath gp = new System.Drawing.Drawing2D.GraphicsPath();
            gp.AddEllipse(0, 0, pbuserPhoto1.Width - 3, pbuserPhoto1.Height - 3);
            Region rg = new Region(gp);
            pbuserPhoto1.Region = rg;

            MemoryStream ms = new MemoryStream(clsConnection.company_user_photo);
            pbuserPhoto1.Image = Image.FromStream(ms);
            pbuserPhoto2.Image = Image.FromStream(ms);

            lblUserName.Text = clsConnection.user_name;
            read_company_info(clsConnection.companyCode);

            lblcomCode.Text = clsConnection.companyCode;

            read_Partinership_requests(clsConnection.companyCode, "requested");
            lblRequests.Text = request_mode;
            read_Partinership_requests(clsConnection.companyCode, "accepted");
            lblAccepted.Text = request_mode;
            read_Partinership_requests(clsConnection.companyCode, "rejected");
            lblRejected.Text = request_mode;
        }

        private void linkLabel13_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmCompanyList frm = new frmCompanyList();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.ShowDialog();
        }

        private void linkLabel16_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmConnections frm = new frmConnections();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.ShowDialog();
        }

        private void lblRequested_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmSentRequests frm = new frmSentRequests();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.fill_grid("Requested");
            frm.ShowDialog();
        }

        private void lblaccept_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmSentRequests frm = new frmSentRequests();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.fill_grid("Accepted");
            frm.ShowDialog();
        }

        private void lblreject_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmSentRequests frm = new frmSentRequests();
            frm.StartPosition = FormStartPosition.CenterScreen;
            frm.fill_grid("Rejected");
            frm.ShowDialog();
        }

        private void panel_home_Paint(object sender, PaintEventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblTime.Text = DateTime.Now.ToShortTimeString();
        }
    }
}
