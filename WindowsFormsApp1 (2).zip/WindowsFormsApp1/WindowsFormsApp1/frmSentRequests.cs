﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Imaging;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{
    public partial class frmSentRequests : Form
    {
        clsConnection obj = new clsConnection();
        public frmSentRequests()
        {
            InitializeComponent();
        }

        private void frmSentRequests_Load(object sender, EventArgs e)
        {

        }
        public void fill_grid(string mode)
        {
            obj.conn_open();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = obj.cnn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select first_company,second_code,Second_company,Cooperate_mode,Request_mode,Req_date from co_operations where Request_mode = '" + mode + "' and first_code = " + clsConnection.companyCode;
            MySqlDataAdapter sqlDataAdap = new MySqlDataAdapter(cmd);
            DataTable dtRecord = new DataTable();
            sqlDataAdap.Fill(dtRecord);
            dataGridView1.DataSource = dtRecord;
            obj.conn_close();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
