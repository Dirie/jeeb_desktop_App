﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Drawing.Imaging;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{
    public partial class frmConnections : Form
    {
        clsConnection obj = new clsConnection();
        public frmConnections()
        {
            InitializeComponent();
            fill_grid();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Close();
            
        }
        private void fill_grid()
        {
            obj.conn_open();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = obj.cnn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from company_connections where myCompany = " + clsConnection.companyCode;
            MySqlDataAdapter sqlDataAdap = new MySqlDataAdapter(cmd);

            DataTable dtRecord = new DataTable();
            sqlDataAdap.Fill(dtRecord);
            dataGridView1.DataSource = dtRecord;
            obj.conn_close();
        }
    }
}
