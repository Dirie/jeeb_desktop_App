﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{
    public partial class frmCodes : Form
    {
        clsConnection obj = new clsConnection();
        public frmCodes()
        {
            InitializeComponent();
        }
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (cboprovinces.Text == "")
            {
                MessageBox.Show("select or Enter province.");
                cboprovinces.Focus();
                return;
            }
            if (txtcode.Text == "")
            {
                MessageBox.Show("Enter start code!");
                txtcode.Focus();
                return;
            }
            if(!is_record_exist(cboprovinces.Text.ToString()))
            {
                add_record();
                MessageBox.Show("Record Successfully Added!");
            }
            else
            {
                if (MessageBox.Show("Do you want to update?", "User Info", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    Update_record();
                    MessageBox.Show("Record Successfully Updated!");
                }
            }
            txtcode.Clear();
            cboprovinces.Text = "";
            read_codes();
        }
        private void add_record()
        {
            MySqlCommand cmd = new MySqlCommand();
            MySqlParameter prm = new MySqlParameter();
            String sql = "Insert into company_codes (intial,province)";
            sql += " values(@intial,@province)";
            obj.conn_open();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = obj.cnn;
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@intial", txtcode.Text);
            cmd.Parameters.AddWithValue("@province", cboprovinces.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            obj.conn_close();
        }
        private void Update_record()
        {
            MySqlCommand cmd = new MySqlCommand();
            MySqlParameter prm = new MySqlParameter();
            String sql = "update company_codes set intial=@intial where province=@province";
            obj.conn_open();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = obj.cnn;
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@intial", txtcode.Text);
            cmd.Parameters.AddWithValue("@province", cboprovinces.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            obj.conn_close();
        }
        private bool is_record_exist(String id)
        {
            obj.conn_open();
            String sql = "Select * from company_codes where province='" + id + "'";
            MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
            MySqlDataReader dr;
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                dr.Dispose();
                obj.conn_close();
                return true;
            }
            else
            {
                dr.Dispose();
                obj.conn_close();
                return false;
            }
        }
        private void read_codes()
        {
            obj.conn_open();
            String sql = "Select * from company_codes";
            MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
            MySqlDataReader dr;
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                lstcodes.Items.Add(dr[0].ToString() + "    " + dr[1].ToString());
            }
            dr.Dispose();
            obj.conn_close();
        }
        private void frmCodes_Load(object sender, EventArgs e)
        {
            read_codes();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
