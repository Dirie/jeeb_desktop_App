﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Windows.Forms;
using WindowsFormsApp1;
using Bunifu.Framework.UI;
using System.Drawing.Imaging;
using System.IO;


namespace WindowsFormsApp1
{
    public partial class frmlogin : Form
    {
        clsConnection obj = new clsConnection();
       

        public frmlogin()
        {
            InitializeComponent();
        }


        private void frmlogin_Load(object sender, EventArgs e)
        {
            cbotype.selectedIndex = 0;
            panel_register.Visible = false;
            panellogin.Visible = true;
           
       
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

       
        public void Text_LostFocus(object sender, EventArgs e)
        {
        }
        public void Text_GotFocus(object sender, EventArgs e)
        {       
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            frmforgotpass frm = new frmforgotpass();
            frm.ShowDialog();
        }
        private void lblLogIn_Click(object sender, EventArgs e)
        {
            panel_register.Visible = false;
            panellogin.Visible = true;
        }

        private void lblRegister_Click(object sender, EventArgs e)
        {
            panel_register.Visible = true;
            panellogin.Visible = false;
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
           
          

            if (cbotype.selectedIndex==0)
            {
                if (logIn_company(txtemail.Text, txtpass.Text) == true)
                {
                    MDIJeeb frm = new MDIJeeb();
                    frm.Show();
                    this.Hide();
                }

            }
            else if(cbotype.selectedIndex==1)
            {
                if (logIn_admin(txtemail.Text, txtpass.Text) == true)
                {
                    MDIAdmin frm = new MDIAdmin();
                    frm.Show();
                    this.Hide();
                }
            }

           
        }
        private void txtemail_OnValueChanged(object sender, EventArgs e)
        {
            if (cbotype.selectedIndex == 0)
            {
                obj.conn_open();
                String sql = "Select * from company_users where Email='" + txtemail.Text.Replace("'", "''") + "'";
                MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
                MySqlDataReader dr;
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    byte[] photo_aray;
                    photo_aray = (byte[])dr[4];
                    MemoryStream ms = new MemoryStream(photo_aray);
                    pictureBox1.Image = Image.FromStream(ms);
                }
                dr.Dispose();
                obj.conn_close();
            }
            else if (cbotype.selectedIndex == 1)
            {
                obj.conn_open();
                String sql = "Select * from admin_table where email='" + txtemail.Text.Replace("'","''") + "'";
                MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
                MySqlDataReader dr;
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    byte[] photo_aray;
                    photo_aray = (byte[])dr[12];
                    MemoryStream ms = new MemoryStream(photo_aray);
                    pictureBox1.Image = Image.FromStream(ms);
                }

                dr.Dispose();
                obj.conn_close();

            }
        }
        private void txtemail_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13)
            {
                txtpass.Text = "";
                txtpass.Focus();
            }
        }
        private bool logIn_admin(string email, string pass)
        {
            obj.conn_open();
            String sql = "Select * from admin_table where email='" + email.Replace("'", "''") + "' and pass='" + pass.Replace("'", "''") + "'";
            MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
            MySqlDataReader dr;
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                clsConnection.AdminFullname = dr[1].ToString();
                clsConnection.AdminEmail = dr[2].ToString();
                clsConnection.admin_photo = (byte[])dr[12];
                clsConnection.Adminid = dr[0].ToString();
                clsConnection.adminpass = dr[3].ToString();
                dr.Dispose();
                obj.conn_close();
                return true;
            }
            else
            {
                dr.Dispose();
                obj.conn_close();
                return false;
            }
        }
        private bool logIn_company(string email, string pass)
        {
            obj.conn_open();
            String sql = "Select * from company_users where email='" + email.Replace("'", "''") + "' and pass='" + pass.Replace("'", "''") + "'";
            MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
            MySqlDataReader dr;
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                clsConnection.companyCode = dr[7].ToString();
                clsConnection.comp_user_email = dr[1].ToString();
                clsConnection.company_user_photo = (byte[])dr[4];
                clsConnection.comp_user_pass = dr[2].ToString();
                clsConnection.user_name = dr[8].ToString();
                dr.Dispose();
                obj.conn_close();
                return true;
            }
            else
            {
                dr.Dispose();
                obj.conn_close();
                return false;
            }
        }

        private void txtpass_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (e.KeyChar == 13)
            {


                if (cbotype.selectedIndex == 0)
                {
                    if (logIn_company(txtemail.Text, txtpass.Text) == true)
                    {
                        MDIJeeb frm = new MDIJeeb();
                        frm.Show();
                        this.Hide();
                    }
                   
                }
                else if (cbotype.selectedIndex == 1)
                {
                    if (logIn_admin(txtemail.Text, txtpass.Text) == true)
                    {
                        MDIAdmin frm = new MDIAdmin();
                        frm.Show();
                        this.Hide();
                    }

                }

            }
        }

        private void txtcompanyName_Enter(object sender, EventArgs e)
        {
            if (txtcompanyName.Text == "Company Name")
            {
                txtcompanyName.Text = "";
            }
            
        }

        private void txtfname_Enter(object sender, EventArgs e)
        {
            if (txtfname.Text == "First Name")
            {
                txtfname.Text = "";
            }
            
        }

        private void txtLastName_Enter(object sender, EventArgs e)
        {
            if (txtLastName.Text == "Last Name")
            {
                txtLastName.Text = "";
            }
            
        }

        private void txtphone_Enter(object sender, EventArgs e)
        {
            if (txtphone.Text == "Phone")
            {
                txtphone.Text = "";
            }
            
        }

        private void txtcomEmail_Enter(object sender, EventArgs e)
        {
            if (txtcomEmail.Text == "Email")
            {
                txtcomEmail.Text = "";
            }
            
        }

        private void txtcomPass_Enter(object sender, EventArgs e)
        {
            if (txtcomPass.Text == "Passowrd")
            {
                txtcomPass.Text = "";
            }
            
        }

        private void txtcomCpass_Enter(object sender, EventArgs e)
        {
            if (txtcomCpass.Text == "Confirm Password")
            {
                txtcomCpass.Text = "";
            }
           
        }

        private void btnSignup_Click(object sender, EventArgs e)
        {
            if (txtcompanyName.Text == "" || txtcompanyName.Text == "Company Name")
            {
                MessageBox.Show("Enter Company Name!");
                txtcompanyName.Focus();
                return;
            }
            if (txtfname.Text == "" || txtfname.Text == "First Name")
            {
                MessageBox.Show("Enter First Name!");
                txtfname.Focus();
                return;
            }
            if (txtLastName.Text == "" || txtLastName.Text == "Last Name")
            {
                MessageBox.Show("Enter Last Name!");
                txtLastName.Focus();
                return;
            }
            if (txtphone.Text == "" || txtphone.Text == "Phone")
            {
                MessageBox.Show("Enter your phone!");
                txtphone.Focus();
                return;
            }
            if (txtaltPhone.Text == "" || txtaltPhone.Text == "Alternate Phone")
            {
                MessageBox.Show("Enter Alternate Phone!");
                txtaltPhone.Focus();
                return;
            }
            if (txtcity.Text == "" || txtcity.Text == "City")
            {
                MessageBox.Show("Enter your City!");
                txtcity.Focus();
                return;
            }
            if (txtprovince.Text == "" || txtprovince.Text == "Province")
            {
                MessageBox.Show("Enter your Province!");
                txtprovince.Focus();
                return;
            }
            if (txtcountry.Text == "" || txtcountry.Text == "Country")
            {
                MessageBox.Show("Enter your Country!");
                txtcountry.Focus();
                return;
            }
            if (txtcomEmail.Text == "" || txtcomEmail.Text == "Email")
            {
                MessageBox.Show("Enter Email!");
                txtcomEmail.Focus();
                return;
            }
            if (txtcomPass.Text == "" || txtcomPass.Text == "Passowrd")
            {
                MessageBox.Show("Enter Password!");
                txtcomPass.Focus();
                return;
            }
            if (txtcomCpass.Text == "" || txtcomCpass.Text == "Confirm Password")
            {
                MessageBox.Show("Confirm Password!");
                txtcomCpass.Focus();
                return;
            }
            if (txtcomCpass.Text != txtcomPass.Text)
            {
                MessageBox.Show("Password does not match!");
                txtcomCpass.Focus();
                return;
            }

            System.Text.RegularExpressions.Regex rEMail = new System.Text.RegularExpressions.Regex(@"^[a-zA-Z][\w\.-]{2,28}[a-zA-Z0-9]@[a-zA-Z0-9][\w\.-]*[a-zA-Z0-9]\.[a-zA-Z][a-zA-Z\.]*[a-zA-Z]$");
            if (txtcomEmail.Text.Length > 0)
            {
                if (!rEMail.IsMatch(txtcomEmail.Text))
                {
                    MessageBox.Show("E-Mail expected", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtcomEmail.Text = "";
                    txtcomEmail.Focus();
                    return;
                }
            }

            if (MessageBox.Show("Are you sure that you registering " + txtcompanyName.Text.ToUpper() + "?", "User Info", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                add_company();
                MessageBox.Show("Congratulations, Your request has sent to JEEB System" + "\n" + " a few minutes later, you will find acceptence email.");
                panellogin.Visible = true;
                panel_register.Visible = false;
                clear_objects();
            }
        }

        private void clear_objects()
        {
            txtcompanyName.Text = "Company Name";
            txtfname.Text = "First Name";
            txtLastName.Text = "Last Name";
            txtphone.Text = "Phone";
            txtaltPhone.Text = "Alternate Phone";
            txtcity.Text = "City";
            txtprovince.Text = "Province";
            txtcountry.Text = "Country";
            txtcomEmail.Text = "Email";
            txtcomPass.Text = "Passowrd";
            txtcomCpass.Text = "Confirm Password";

        }

        private void add_company()
        {
            MySqlCommand cmd = new MySqlCommand();
            MySqlParameter prm = new MySqlParameter();
            String sql = "Insert into companyrequests (company_name,firstName,lastName,phone,city,province,Country,email,pass,req_date,altPhone)";
            sql += " values(@company_name,@firstName,@lastName,@phone,@city,@province,@Country,@email,@pass,@req_date,@altPhone)";
            obj.conn_open();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = obj.cnn;
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@company_name", txtcompanyName.Text);
            cmd.Parameters.AddWithValue("@firstName", txtfname.Text);
            cmd.Parameters.AddWithValue("@lastName", txtLastName.Text);
            cmd.Parameters.AddWithValue("@phone", txtphone.Text);
            cmd.Parameters.AddWithValue("@city", txtcity.Text);
            cmd.Parameters.AddWithValue("@province", txtprovince.Text);
            cmd.Parameters.AddWithValue("@Country", txtcountry.Text);
            cmd.Parameters.AddWithValue("@email", txtcomEmail.Text);
            cmd.Parameters.AddWithValue("@pass", txtcomPass.Text);
            cmd.Parameters.AddWithValue("@req_date", DateTime.Now);
            cmd.Parameters.AddWithValue("@altPhone", txtaltPhone.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            obj.conn_close();
        }

        private void txtprovince_Enter(object sender, EventArgs e)
        {
            if (txtprovince.Text == "Province")
            {
                txtprovince.Text = "";
            }
        }

        private void txtcountry_Enter(object sender, EventArgs e)
        {
            if (txtcountry.Text == "Country")
            {
                txtcountry.Text = "";
            }
        }

        private void txtcity_Enter(object sender, EventArgs e)
        {
            if (txtcity.Text == "City")
            {
                txtcity.Text = "";
            }
        }

        private void bunifuMetroTextbox1_Enter(object sender, EventArgs e)
        {
            if (txtaltPhone.Text == "Alternate Phone")
            {
                txtaltPhone.Text = "";
            }
        }
    }








}
