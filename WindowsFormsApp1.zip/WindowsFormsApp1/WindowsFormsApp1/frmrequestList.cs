﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;
using WindowsFormsApp1;

namespace WindowsFormsApp1
{
    public partial class frmrequestList : Form
    {
        clsConnection obj = new clsConnection();
        public frmrequestList()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmrequestList_Load(object sender, EventArgs e)
        {
            fill_grid();
        }

        private void fill_grid()
        {
            obj.conn_open();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection =obj.cnn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from companyrequests";
            MySqlDataAdapter sqlDataAdap = new MySqlDataAdapter(cmd);

            DataTable dtRecord = new DataTable();
            sqlDataAdap.Fill(dtRecord);
            dataGridView1.DataSource = dtRecord;
            obj.conn_close();
        }

        private void dataGridView1_DoubleClick(object sender, EventArgs e)
        {
            
            frmCompany frm = new frmCompany();
            frm.StartPosition = FormStartPosition.CenterScreen;
            //MessageBox.Show(dataGridView1.CurrentRow.Cells[0].Value.ToString());
            frm.txtcompanyName.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            frm.txtfName.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString() + " " + dataGridView1.CurrentRow.Cells[3].Value.ToString();
            frm.txtphone.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            frm.txtemail.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            frm.txtpassword.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();
            frm.txtcity.Text = dataGridView1.CurrentRow.Cells[8].Value.ToString();
            frm.cboProvince.Text = dataGridView1.CurrentRow.Cells[9].Value.ToString();
            frm.cboCountry.Text = dataGridView1.CurrentRow.Cells[10].Value.ToString();
            frm.txtaltPhone.Text = dataGridView1.CurrentRow.Cells[11].Value.ToString();
            frm.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
