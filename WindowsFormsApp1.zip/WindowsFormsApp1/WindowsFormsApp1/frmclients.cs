﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1;
using MySql.Data.MySqlClient;
using System.IO;
using System.Drawing.Imaging;

namespace WindowsFormsApp1
{
    public partial class frmclients : Form

    {
        private clsConnection obj = new clsConnection();
        public string cust_code;
        public string Company_name;

        public frmclients()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
           
            if (txtcustid.Text == "")
            {
                MessageBox.Show("Enter Customer Identification");
                txtcustid.Focus();
                return;
            }
            if (txtcustName.Text == "")
            {
                MessageBox.Show("Enter Customer Name");
                txtcustName.Focus();
                return;
            }
            if (txtphone.Text == "")
            {
                MessageBox.Show("Enter Customer Phone");
                txtphone.Focus();
                return;
            }
            if (txtAccountNumber.Text.Length < 9)
            {
                MessageBox.Show("Enter Corect Phone");
                txtphone.Focus();
                return;
            }
            if (txtpin.Text == "")
            {
                MessageBox.Show("Enter 5-digit pin-number!");
                txtpin.Focus();
                return;
            }


            if (!is_record_exist(txtphone.Text))
            {
                add_record();
                add_Activation();
                MessageBox.Show("Record Successfully Added! \n Account-number:" + txtAccountNumber.Text + " \n Pin:" + txtpin.Text);
            }
            else
            {
                    read_his_company(cust_code);
                    MessageBox.Show("Waan ka xunnahay Macaamiilkan wuxuu ka diiwaan ka shanyahay " + Company_name + " \n Hadii aad rabto inaad waxka badasho la xeriir admin-ka, thanks");
            }
            clear_objects();
        }
        private void clear_objects()
        {
            txtcustid.Text = "";
            txtcustName.Text = "";
            txtphone.Text = "";
            txtAccountNumber.Text = "";
            Random generator = new Random();
            String r = generator.Next(0, 100000).ToString("D5");
            txtpin.Text = r;
        }
        private void add_record()
        {
            MemoryStream ms = new MemoryStream();
            pbcustomer.Image.Save(ms, ImageFormat.Jpeg);
            byte[] photo_aray = new byte[ms.Length];
            ms.Position = 0;
            ms.Read(photo_aray, 0, photo_aray.Length);

            MySqlCommand cmd = new MySqlCommand();
            MySqlParameter prm = new MySqlParameter();
            String sql = "Insert into customers (id,Name,phone,Account,Amount,code,pin,price,Active,photo,User_Email,RegDate,AccType )";
            sql += " values(@id,@Name,@phone,@Account,@Amount,@code,@pin,@price,@Active,@photo,@User_Email,@RegDate,@AccType)";
            obj.conn_open();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = obj.cnn;
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@id", txtcustid.Text);
            cmd.Parameters.AddWithValue("@Name", txtcustName .Text);
            cmd.Parameters.AddWithValue("@phone", txtphone.Text);
            cmd.Parameters.AddWithValue("@Account", txtAccountNumber.Text);
            cmd.Parameters.AddWithValue("@Amount", 0);
            cmd.Parameters.AddWithValue("@code", clsConnection.companyCode);
            cmd.Parameters.AddWithValue("@pin", (txtpin.Text));
            cmd.Parameters.AddWithValue("@price", 50);
            cmd.Parameters.AddWithValue("@Active", "Yes");
            cmd.Parameters.AddWithValue("@User_Email", clsConnection.comp_user_email);
            cmd.Parameters.AddWithValue("@photo", photo_aray);
            cmd.Parameters.AddWithValue("@RegDate", DateTime.Now);
            cmd.Parameters.AddWithValue("@AccType", cboAccType.SelectedItem);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            obj.conn_close();
        }
        private bool is_record_exist(String phone)
        {
            obj.conn_open();
            String sql = "Select * from customers where phone='" + phone + "'";
            MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
            MySqlDataReader dr;
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                cust_code = dr[5].ToString();
                dr.Dispose();
                obj.conn_close();
                return true;
            }
            else
            {
                dr.Dispose();
                obj.conn_close();
                return false;
            }
        }
        private void  read_his_company(String cust_code)
        {
            obj.conn_open();
            String sql = "Select * from companies where code='" + cust_code + "'";
            MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
            MySqlDataReader dr;
            dr = cmd.ExecuteReader();
            if (dr.Read())
            {
                Company_name = dr[1].ToString();
            }
            dr.Dispose();
            obj.conn_close();
        }
        private void label1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }
        private void add_Activation()
        {
            MySqlCommand cmd = new MySqlCommand();
            MySqlParameter prm = new MySqlParameter();
            String sql = "Insert into activations (AccNo,start,end,month,price,amount,Active_mode,code)";
            sql += " values(@AccNo,@start,@end,@month,@price,@amount,@Active_mode,@code)";
            obj.conn_open();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = obj.cnn;
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@AccNo", txtAccountNumber.Text);
            cmd.Parameters.AddWithValue("@start", DateTime.Now.Date );
            cmd.Parameters.AddWithValue("@end", DateTime.Now.Date.AddMonths(1));
            cmd.Parameters.AddWithValue("@month", 1);
            cmd.Parameters.AddWithValue("@price", 50);
            cmd.Parameters.AddWithValue("@amount", 50);
            cmd.Parameters.AddWithValue("@Active_mode", "Trial");
            cmd.Parameters.AddWithValue("@code", clsConnection.companyCode);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            obj.conn_close();
        }
        private void txtphone_OnValueChanged(object sender, EventArgs e)
        {
            if(txtphone.Text != "")
            {
                long  i;
                i = Convert.ToInt64(txtphone.Text);
                txtAccountNumber.Text = Convert.ToInt64(clsConnection.companyCode + i).ToString();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void frmclients_Load(object sender, EventArgs e)
        {
            Random generator = new Random();
            String r = generator.Next(0, 100000).ToString("D5");
            txtpin.Text = r;

            cboAccType.SelectedIndex = 0;
        }
    }
}
