﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1;
using MySql.Data.MySqlClient;

namespace WindowsFormsApp1
{
    public partial class frmCompanyList : Form
    {
        clsConnection obj = new clsConnection();
        public frmCompanyList()
        {
            InitializeComponent();
        }

        private void frmCompanyList_Load(object sender, EventArgs e)
        {
            fill_grid();
        }
        private void fill_grid()
        {
            obj.conn_open();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = obj.cnn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from companies";
            MySqlDataAdapter sqlDataAdap = new MySqlDataAdapter(cmd);

            DataTable dtRecord = new DataTable();
            sqlDataAdap.Fill(dtRecord);
            dataGridView1.DataSource = dtRecord;
            obj.conn_close();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtsearch_OnTextChange(object sender, EventArgs e)
        {
            obj.conn_open();
            MySqlCommand cmd = new MySqlCommand();
            cmd.Connection = obj.cnn;
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "Select * from companies where code like '%" + txtsearch.text + "%'";
            MySqlDataAdapter sqlDataAdap = new MySqlDataAdapter(cmd);

            DataTable dtRecord = new DataTable();
            sqlDataAdap.Fill(dtRecord);
            dataGridView1.DataSource = dtRecord;
            obj.conn_close();
        }
    }
}
