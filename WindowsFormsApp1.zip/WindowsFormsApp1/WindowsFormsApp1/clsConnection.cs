﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using MySql.Data.MySqlClient;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using WindowsFormsApp1;
using System.Net;
using System.Net.Mail;

namespace WindowsFormsApp1
{


     class clsConnection
    {

        //private String conn_string = "server=sql12.freemysqlhosting.net:3306;database=sql12196566;uid=sql12196566;pwd=S7k5SrIChq;";
        private String conn_string = "server=localhost;database=jeeb;uid=root;pwd=;";

        public MySqlConnection cnn = new MySqlConnection();

        public static string AdminEmail;
        public static string companyName;
        public static string Adminid;
        public static string adminpass;
        public static string comp_user_pass;
        public static string comp_user_email;

        public static string AdminFullname;
        public static string companyCode;
        public static string user_name;

        public static byte[] company_logo;
        public static byte[] company_user_photo;
        public static byte[] admin_photo;


        public void conn_open()
        {
            if (cnn.State == System.Data.ConnectionState.Closed)
            {
                cnn.ConnectionString = conn_string;
                cnn.Open();
            }
        }

        public void conn_close()
        {
            if (cnn.State == System.Data.ConnectionState.Open)
            {
                cnn.Close();
            }
        }

         

    }
}
