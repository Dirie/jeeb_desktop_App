﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using MySql.Data.MySqlClient;
using WindowsFormsApp1;
using System.Drawing.Imaging;


namespace WindowsFormsApp1
{
    public partial class frmChangeAdmin : Form
    {
        clsConnection obj = new clsConnection();
        public frmChangeAdmin()
        {
            InitializeComponent();
        }

        private void frmChangeAdmin_Load(object sender, EventArgs e)
        {
            txtemail.Text = clsConnection.AdminEmail;
            txtemail.Enabled = false;

        }

        private void label2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtcurentPass.Text == "" || txtcurentPass.Text == "Current Password")
            {
                MessageBox.Show("Enter Current Password!");
                txtcurentPass.Focus();
                return;
            }
            if (txtcurentPass.Text != clsConnection.adminpass)
            {
                MessageBox.Show("Current Password is wrong!");
                this.Close();
                return;
            }
            if (txtpass.Text == "" || txtpass.Text == "Password")
            {
                MessageBox.Show("Enter Password!");
                txtpass.Focus();
                return;
            }
            if (txtcpass.Text == "" || txtcpass.Text == "Password")
            {
                MessageBox.Show("confirm password!");
                txtcpass.Focus();
                return;
            }
            if (txthint.Text == "")
            {
                MessageBox.Show("Enter hint!");
                txthint.Focus();
                return;
            }
            if (txtpass.Text != txtcpass.Text)
            {
                MessageBox.Show("Password does not match!");
                txthint.Focus();
                return;
            }
            if (MessageBox.Show("Do you want to update?", "User Info", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                Update_record();
                MessageBox.Show("Record Successfully Updated!");
               
                clearobjects();
            }

            this.Close();
        }
        private void clearobjects()
        {
            txtcpass.Text = "";
            txtpass.Text = "";
            txthint.Text = "";

        }
        private void Update_record()
        {
           

            MySqlCommand cmd = new MySqlCommand();
            MySqlParameter prm = new MySqlParameter();
            String sql = "update admin_table set Pass=@Pass,Hint=@Hint where email=@email";

            obj.conn_open();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = obj.cnn;
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@Pass", txtpass.Text);
            cmd.Parameters.AddWithValue("@email", txtemail.Text);
            cmd.Parameters.AddWithValue("@Hint",txthint.Text);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            obj.conn_close();
        }

        private void txtpass_Enter(object sender, EventArgs e)
        {
            txtpass.Text = "";

        }

        private void txtcpass_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtpass_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtcpass_Enter(object sender, EventArgs e)
        {
            txtcpass.Text = "";
        }

        private void txtcurentPass_Enter(object sender, EventArgs e)
        {
            txtcurentPass.Text = "";
        }
    }
}
