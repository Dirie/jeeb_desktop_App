﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;
using System.Drawing.Imaging;

namespace WindowsFormsApp1
{
    public partial class frmPartinershipLists : Form
    {
        clsConnection obj = new clsConnection();
        public frmPartinershipLists()
        {
            InitializeComponent();
        }

        private void frmPartinershipLists_Load(object sender, EventArgs e)
        {

        }
        public void fill_grid_type(string request_mode)
        {
            dataGridView1.Rows.Clear();
            obj.conn_open();
            String sql = "Select first_code,first_company,Request_mode,Des from co_operations where Request_mode='" + request_mode + "' and second_code ='" + clsConnection.companyCode + "'";
            MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
            MySqlDataReader dr;
            dr = cmd.ExecuteReader();
            int i = 0;
            while(dr.Read())
            {
                dataGridView1.Rows.Add();
                dataGridView1.Rows[i].Cells[0].Value = dr[0].ToString();
                dataGridView1.Rows[i].Cells[1].Value = dr[1].ToString();
                dataGridView1.Rows[i].Cells[2].Value = dr[2].ToString();
                dataGridView1.Rows[i].Cells[3].Value = dr[3].ToString();
                i = i + 1;
            }
            dr.Dispose();
            obj.conn_close();
        }
        private void txtsearch_OnTextChange(object sender, EventArgs e)
        {
            if (rbAccepted.Checked ==true)
            {
                dataGridView1.Rows.Clear();
                obj.conn_open();
                String sql = "Select first_code,first_company,Request_mode,Des from co_operations where Request_mode='" + rbAccepted.Text + "' and second_code ='" + clsConnection.companyCode + "' and first_code like '%" + txtsearch.text + "%'";
                MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
                MySqlDataReader dr;
                dr = cmd.ExecuteReader();
                int i = 0;
                while (dr.Read())
                {
                    dataGridView1.Rows.Add();
                    dataGridView1.Rows[i].Cells[0].Value = dr[0].ToString();
                    dataGridView1.Rows[i].Cells[1].Value = dr[1].ToString();
                    dataGridView1.Rows[i].Cells[2].Value = dr[2].ToString();
                    dataGridView1.Rows[i].Cells[3].Value = dr[3].ToString();
                    i = i + 1;
                }
                dr.Dispose();
                obj.conn_close();
            }
            else if(rbRequested.Checked == true)
            {
                dataGridView1.Rows.Clear();
                obj.conn_open();
                String sql = "Select first_code,first_company,Request_mode,Des from co_operations where Request_mode='" + rbRequested.Text + "' and second_code ='" + clsConnection.companyCode + "' and first_code like '%" + txtsearch.text + "%'";
                MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
                MySqlDataReader dr;
                dr = cmd.ExecuteReader();
                int i = 0;
                while (dr.Read())
                {
                    dataGridView1.Rows.Add();
                    dataGridView1.Rows[i].Cells[0].Value = dr[0].ToString();
                    dataGridView1.Rows[i].Cells[1].Value = dr[1].ToString();
                    dataGridView1.Rows[i].Cells[2].Value = dr[2].ToString();
                    dataGridView1.Rows[i].Cells[3].Value = dr[3].ToString();
                    i = i + 1;
                }
                dr.Dispose();
                obj.conn_close();
            }
            else if(rbRejected.Checked == true)
            {
                dataGridView1.Rows.Clear();
                obj.conn_open();
                String sql = "Select first_code,first_company,Request_mode,Des from co_operations where Request_mode='" + rbRejected.Text + "' and second_code ='" + clsConnection.companyCode + "' and first_code like '%" + txtsearch.text + "%'";
                MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
                MySqlDataReader dr;
                dr = cmd.ExecuteReader();
                int i = 0;
                while (dr.Read())
                {
                    dataGridView1.Rows.Add();
                    dataGridView1.Rows[i].Cells[0].Value = dr[0].ToString();
                    dataGridView1.Rows[i].Cells[1].Value = dr[1].ToString();
                    dataGridView1.Rows[i].Cells[2].Value = dr[2].ToString();
                    dataGridView1.Rows[i].Cells[3].Value = dr[3].ToString();
                    i = i + 1;
                }
                dr.Dispose();
                obj.conn_close();
            }
            
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void rbAccepted_CheckedChanged(object sender, EventArgs e)
        {
            if (rbAccepted.Checked == true)
            {
                fill_grid_type(rbAccepted.Text);
            }
        }

        private void rbRequested_CheckedChanged(object sender, EventArgs e)
        {
            if (rbRequested.Checked == true)
            {
                fill_grid_type(rbRequested.Text);
            }
        }

        private void rbRejected_CheckedChanged(object sender, EventArgs e)
        {
            if (rbRejected.Checked == true)
            {
                fill_grid_type(rbRejected.Text);
            }
        }

        private void btnChange_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count >= 0)
            {
                Update_record();
                MessageBox.Show("Record updated!");
            }

        }
        private void Update_record()
        {
            for (int i=0; i < dataGridView1.Rows.Count; i++)
            {
                MySqlCommand cmd = new MySqlCommand();
                MySqlParameter prm = new MySqlParameter();
                String sql = "update co_operations set Des=@Des, Request_mode=@Request_mode,Accept_Date=@Accept_Date where first_code=@first_code and second_code=@second_code ";

                obj.conn_open();
                cmd.CommandType = CommandType.Text;
                cmd.Connection = obj.cnn;
                cmd.CommandText = sql;
                cmd.Parameters.AddWithValue("@first_code", dataGridView1.Rows[i].Cells[0].Value.ToString());
                cmd.Parameters.AddWithValue("@second_code", clsConnection.companyCode);
                cmd.Parameters.AddWithValue("@Request_mode", dataGridView1.Rows[i].Cells[2].Value.ToString());
                cmd.Parameters.AddWithValue("@Accept_Date", DateTime.Now);
                cmd.Parameters.AddWithValue("@Des", dataGridView1.Rows[i].Cells[3].Value.ToString());
                cmd.ExecuteNonQuery();
                cmd.Dispose();
                obj.conn_close();
            }
           
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
          
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow.Cells[2].Value.ToString() == "Accepted")
            {
                dataGridView1.CurrentRow.Cells[3].Value = "Request Accepted";
            }
            else if (dataGridView1.CurrentRow.Cells[2].Value.ToString() == "Rejected")
            {
                dataGridView1.CurrentRow.Cells[3].Value = "Request Rejected";
            }
        }
    }
}
