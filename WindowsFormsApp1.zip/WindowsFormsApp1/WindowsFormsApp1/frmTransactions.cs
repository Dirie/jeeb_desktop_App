﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1;
using MySql.Data.MySqlClient;
using System.Drawing.Imaging;
using System.IO;

namespace WindowsFormsApp1
{
    public partial class frmTransactions : Form
    {
        clsConnection obj = new clsConnection();
        public frmTransactions()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbotranType.SelectedIndex == 0)
            {
                clear_objects();
                panelFrom.Visible = true;
                panelTo.Visible = false;

                txtTo.Visible = false;
                txtfrom.Visible = true;
                lblTo.Visible = false;
                lblfrom.Visible = true;
            }
            else if (cbotranType.SelectedIndex == 1)
            {
                clear_objects();
                panelFrom.Visible = true;
                panelTo.Visible = false;

                txtTo.Visible = false;
                txtfrom.Visible = true;
                lblTo.Visible = false;
                lblfrom.Visible = true;
            }
            else if (cbotranType.SelectedIndex == 2)
            {
                clear_objects();
                panelFrom.Visible = true;
                panelTo.Visible = true;

                txtTo.Visible = true;
                txtfrom.Visible = true;
                lblTo.Visible = true;
                lblfrom.Visible = true;
            }
            else if (cbotranType.SelectedIndex == 3)
            {
                clear_objects();
                panelFrom.Visible = true;
                panelTo.Visible = true;

                //txtTo.Visible = true;
                txtfrom.Visible = true;
                //lblTo.Visible = true;
                lblfrom.Visible = true;

                obj.conn_open();
                String sql = "Select DISTINCT  Account,code,Name,photo,Amount from customers  where code = '" + clsConnection.companyCode + "' and AccType ='Remitance'";
                MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
                MySqlDataReader dr;
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    txtAccountNoTo.Text = dr[0].ToString();
                    txtToCode.Text = dr[1].ToString();
                    txtToName.Text = dr[2].ToString();
                    MemoryStream ms = new MemoryStream((byte[])dr[3]);
                    pbTo.Image = Image.FromStream(ms);
                    txtToBalance.Text = dr[4].ToString();
                }
                dr.Dispose();
                obj.conn_close();
            }
        }

        private void frmTransactions_Load(object sender, EventArgs e)
        {
            panelFrom.Visible = false;
            panelTo.Visible = false;

            txtTo.Visible = false;
            txtfrom.Visible = false;
            lblTo.Visible = false;
            lblfrom.Visible = false;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if(cbotranType.SelectedIndex == -1)
            {
                MessageBox.Show("Select Transaction type!");
                cbotranType.Focus();
                return;
            }
            if (txtfrom.Text =="")
            {
                MessageBox.Show("Enter From Account!");
                txtfrom.Focus();
                return;
            }
            if (cbotranType.SelectedIndex == 2)
            {
                 if (txtTo.Text == "")
                    {
                       MessageBox.Show("Enter To Account!");
                    txtTo.Focus();
                       return;
                    }
            }
            if (txtAmount.Text == "")
            {
                MessageBox.Show("Enter Amount!");
                txtAmount.Focus();
                return;
            }
            if (txtRefrence.Text == "")
            {
                MessageBox.Show("Enter Reference!");
                txtRefrence.Focus();
                return;
            }
            add_record();
            if (cbotranType.SelectedIndex == 0)
            {
                Deposit_customer(Convert.ToInt64(txtfrom.Text), Convert.ToDouble(txtFromBalance.Text), Convert.ToDouble(txtAmount.Text));
            }
            else if (cbotranType.SelectedIndex == 1)
            {
                Withdrawl_customer (Convert.ToInt64(txtfrom.Text), Convert.ToDouble(txtFromBalance.Text), Convert.ToDouble(txtAmount.Text));
            }
            else if (cbotranType.SelectedIndex == 2)
            {
                Withdrawl_customer(Convert.ToInt64(txtfrom.Text), Convert.ToDouble(txtFromBalance.Text), Convert.ToDouble(txtAmount.Text));
                Deposit_customer(Convert.ToInt64(txtAccountNoTo.Text), Convert.ToDouble(txtToBalance.Text), Convert.ToDouble(txtAmount.Text));
            }
            else if (cbotranType.SelectedIndex == 3)
            {
                Withdrawl_customer(Convert.ToInt64(txtfrom.Text), Convert.ToDouble(txtFromBalance.Text), Convert.ToDouble(txtAmount.Text));
                Deposit_customer(Convert.ToInt64(txtAccountNoTo.Text), Convert.ToDouble(txtToBalance.Text), Convert.ToDouble(txtAmount.Text));
            }
            MessageBox.Show("Transaction successfuly done!!");
            clear_objects();
        }
        private void clear_objects()
        {
            cbotranType.SelectedIndex = -1;
            txtAmount.Clear();
            txtRefrence.Clear();

            txtfrom.Clear();
            txtAccountNoFrom.Clear();
            txtFromCode.Clear();
            txtFromBalance.Clear();
            txtFromName.Clear();
            pbfrom.Image = null;

            txtTo.Clear();
            txtAccountNoTo.Clear();
            txtToCode.Clear();
            txtToBalance.Clear();
            txtToName.Clear();
            pbTo.Image = null;

        }
        private void add_record()
        {
            MySqlCommand cmd = new MySqlCommand();
            MySqlParameter prm = new MySqlParameter();
            String sql = "Insert into transactions (type,mode,f_acc,F_code,t_acc,T_code,amount,reference,User_Email,TrDate )";
            sql += " values(@type,@mode,@f_acc,@F_code,@t_acc,@T_code,@amount,@reference,@User_Email,@TrDate)";
            obj.conn_open();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = obj.cnn;
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@type", cbotranType.SelectedItem);
            cmd.Parameters.AddWithValue("@mode", "Desktop App");
            cmd.Parameters.AddWithValue("@f_acc", txtfrom.Text);
            cmd.Parameters.AddWithValue("@F_code", (txtFromCode.Text));
            cmd.Parameters.AddWithValue("@t_acc", txtTo.Text);
            cmd.Parameters.AddWithValue("@T_code", txtToCode.Text);
            cmd.Parameters.AddWithValue("@amount", txtAmount.Text);
            cmd.Parameters.AddWithValue("@reference", txtRefrence.Text);
            cmd.Parameters.AddWithValue("@User_Email", clsConnection.comp_user_email);
            cmd.Parameters.AddWithValue("@TrDate", DateTime.Now);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            obj.conn_close();
        }
        private void Deposit_customer(Int64 AccNo, Double balance, Double Amount)
        {
            MySqlCommand cmd = new MySqlCommand();
            MySqlParameter prm = new MySqlParameter();
            String sql = "update customers set Amount=@Amount where Account=@Account";
            obj.conn_open();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = obj.cnn;
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@Amount", balance + Amount);
            cmd.Parameters.AddWithValue("@Account", AccNo);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            obj.conn_close();
        }
        private void Withdrawl_customer(Int64 AccNo, Double balance, Double Amount)
        {
            MySqlCommand cmd = new MySqlCommand();
            MySqlParameter prm = new MySqlParameter();
            String sql = "update customers set Amount=@Amount where Account=@Account";
            obj.conn_open();
            cmd.CommandType = CommandType.Text;
            cmd.Connection = obj.cnn;
            cmd.CommandText = sql;
            cmd.Parameters.AddWithValue("@Amount", balance - Amount);
            cmd.Parameters.AddWithValue("@Account", AccNo);
            cmd.ExecuteNonQuery();
            cmd.Dispose();
            obj.conn_close();
        }
        private void txtfrom_TextChanged(object sender, EventArgs e)
        {
            txtfrom.AutoCompleteMode = AutoCompleteMode.Suggest;
            txtfrom.AutoCompleteSource = AutoCompleteSource.CustomSource;
            AutoCompleteStringCollection DataCollection = new AutoCompleteStringCollection();
            GetData_from(DataCollection);
            txtfrom.AutoCompleteCustomSource = DataCollection;
            fill_txtfrom(txtfrom.Text);
        }
        private void fill_txtfrom(string Acc_from)
        {
            obj.conn_open();
            String sql = "Select Account,code,Name,photo,Amount from customers where code = '" + clsConnection.companyCode + "' and Account ='" + Acc_from + "'";
            MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
            MySqlDataReader dr;
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                txtAccountNoFrom.Text = dr[0].ToString();
                txtFromCode.Text = dr[1].ToString();
                txtFromName.Text = dr[2].ToString();
                MemoryStream ms = new MemoryStream((byte[])dr[3]);
                pbfrom.Image = Image.FromStream(ms);
                txtFromBalance.Text = dr[4].ToString();
            }
            dr.Dispose();
            obj.conn_close();
        }
        private void fill_txtTo(string Acc_To)
        {
            obj.conn_open();
            String sql = "Select DISTINCT  Account,code,Name,photo,Amount from connected_customers  where myCompany = '" + clsConnection.companyCode + "' and Account ='" + Acc_To + "'";
            MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
            MySqlDataReader dr;
            dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                txtAccountNoTo.Text = dr[0].ToString();
                txtToCode.Text = dr[1].ToString();
                txtToName.Text = dr[2].ToString();
                MemoryStream ms = new MemoryStream((byte[])dr[3]);
                pbTo.Image = Image.FromStream(ms);
                txtToBalance.Text = dr[4].ToString();
            }
            dr.Dispose();
            obj.conn_close();
        }
        private void GetData_from(AutoCompleteStringCollection dataCollection)
        {
            string sql = "SELECT  Account FROM customers where Account like '%" + txtfrom.Text +  "%' and code=" + clsConnection.companyCode;
            try
            {
                obj.conn_open();
                MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
                MySqlDataAdapter ad = new MySqlDataAdapter();
                DataSet ds = new DataSet();
                ad.SelectCommand = cmd;
                ad.Fill(ds);
                ad.Dispose();
                cmd.Dispose();
                obj.conn_close();
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    dataCollection.Add(row[0].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Can not open connection ! \n" + ex.ToString());
            }
        }
        private void GetData_To(AutoCompleteStringCollection dataCollection)
        {
            string sql = "SELECT DISTINCT Account FROM connected_customers where Account like '%" + txtTo.Text + "%' and myCompany=" + clsConnection.companyCode;
            try
            {
                obj.conn_open();
                MySqlCommand cmd = new MySqlCommand(sql, obj.cnn);
                MySqlDataAdapter ad = new MySqlDataAdapter();
                DataSet ds = new DataSet();
                ad.SelectCommand = cmd;
                ad.Fill(ds);
                ad.Dispose();
                cmd.Dispose();
                obj.conn_close();
                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    dataCollection.Add(row[0].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Can not open connection ! \n" + ex.ToString());
            }
        }
        private void txtTo_TextChanged(object sender, EventArgs e)
        {
            txtTo.AutoCompleteMode = AutoCompleteMode.Suggest;
            txtTo.AutoCompleteSource = AutoCompleteSource.CustomSource;
            AutoCompleteStringCollection DataCollection = new AutoCompleteStringCollection();
            GetData_To(DataCollection);
            txtTo.AutoCompleteCustomSource = DataCollection;
            fill_txtTo(txtTo.Text);
        }
    }
}
    

